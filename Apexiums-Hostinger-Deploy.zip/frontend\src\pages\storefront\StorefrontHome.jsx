import React from 'react';
import Header from '../../components/Header';
import CategoryNav from '../../components/CategoryNav';
import HeroBanner from '../../components/HeroBanner';
import FlashSale from '../../components/FlashSale';
import CategoryGrid from '../../components/CategoryGrid';
import ProductGrid from '../../components/ProductGrid';
import Footer from '../../components/Footer';
import BottomNav from '../../components/BottomNav';
import LoginModal from '../../components/LoginModal';
import CheckoutModal from '../../components/CheckoutModal';
import ProductDetailsModal from '../../components/ProductDetailsModal';
import UserProfileView from '../../components/UserProfileView';
import { openPrivacyPolicy } from '../../components/PrivacyPolicyModal';
import customerSupportIcon from '../../../images/customer_support_green.svg';
import {
  Briefcase,
  ChevronRight,
  Download,
  Headphones,
  Info,
  LogIn,
  LogOut,
  Minus,
  Package,
  Plus,
  ShieldCheck,
  ShoppingBag,
  ShoppingCart,
  Store,
  Truck,
  Upload,
  User,
  X
} from 'lucide-react';
import {
  footerSections,
  flashSaleProducts,
  heroSlides,
  mainNav,
  paymentMethods,
  productSections,
  promoBanners,
  storeLogoSrc,
  storeName,
  topLinks
} from '../../data/storeData';
import { openWhatsApp } from '../../utils/whatsapp';
import { isAdminRole } from '../../utils/roles';

function matchesCategory(product, cat) {
  if (!cat || cat === 'All') return true;
  const c = cat.toLowerCase();
  const pCat = (product.category || '').toLowerCase();
  const pSubCat = (product.subcategory || '').toLowerCase();
  const pTitle = (product.title || '').toLowerCase();

  if (pCat.includes(c) || pSubCat.includes(c) || pTitle.includes(c)) return true;

  if (c === 'fashion' || c === 'clothes' || c === 'shirts') {
    return (
      pCat.includes('fashion') ||
      pCat.includes('shirt') ||
      pCat.includes('cloth') ||
      pCat.includes('accessor') ||
      pTitle.includes('tee') ||
      pTitle.includes('shirt') ||
      pTitle.includes('sneaker') ||
      pTitle.includes('backpack') ||
      pTitle.includes('hoodie')
    );
  }
  if (c === 'electronics' || c === 'mobiles' || c === 'audio' || c === 'gaming' || c === 'laptops') {
    return (
      pCat.includes('electr') ||
      pCat.includes('audio') ||
      pCat.includes('gamin') ||
      pCat.includes('laptop') ||
      pTitle.includes('earbud') ||
      pTitle.includes('watch') ||
      pTitle.includes('phone') ||
      pTitle.includes('tv') ||
      pTitle.includes('controller') ||
      pTitle.includes('camera') ||
      pTitle.includes('keyboard') ||
      pTitle.includes('speaker')
    );
  }
  if (c === 'home & living' || c === 'home' || c === 'decor' || c === 'appliances') {
    return (
      pCat.includes('home') ||
      pCat.includes('decor') ||
      pCat.includes('appliance') ||
      pTitle.includes('lamp') ||
      pTitle.includes('chair') ||
      pTitle.includes('art') ||
      pTitle.includes('desk')
    );
  }
  if (c === 'shoes') {
    return (
      pCat.includes('shoe') ||
      pTitle.includes('shoe') ||
      pTitle.includes('sneaker')
    );
  }
  if (c === 'watches' || c === 'watch') {
    return pCat.includes('watch') || pTitle.includes('watch');
  }
  if (c === 'health & beauty' || c === 'beauty' || c === 'health') {
    return pCat.includes('beaut') || pCat.includes('health') || pTitle.includes('skin') || pTitle.includes('face') || pTitle.includes('fragrance');
  }
  if (c === 'sports' || c === 'fitness') {
    return pCat.includes('sport') || pCat.includes('fitn') || pTitle.includes('shoe') || pTitle.includes('mat');
  }

  return false;
}

function filterProducts(list, query, cat) {
  let result = list;
  if (cat && cat !== 'All') {
    result = result.filter((p) => matchesCategory(p, cat));
  }
  const needle = query.trim().toLowerCase();
  if (!needle) return result;
  return result.filter((product) =>
    [product.title, product.category, product.badge].some((field) => (field || '').toLowerCase().includes(needle))
  );
}

export default function StorefrontHome({ onLogin, session, onLogout }) {
  const [websiteCategories, setWebsiteCategories] = React.useState([]);
  const [websiteProducts, setWebsiteProducts] = React.useState([]);
  const [searchQuery, setSearchQuery] = React.useState('');
  const [selectedCategory, setSelectedCategory] = React.useState('All');
  const [categoryPage, setCategoryPage] = React.useState(null);

  React.useEffect(() => {
    if (categoryPage) window.scrollTo({ top: 0, left: 0, behavior: 'auto' });
  }, [categoryPage]);
  const [hiddenProductIds, setHiddenProductIds] = React.useState(() => {
    try { return JSON.parse(localStorage.getItem('apexiums-hidden-products') || '[]'); } catch { return []; }
  });
  const [cartItems, setCartItems] = React.useState([]);
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);
  const [loginOpen, setLoginOpen] = React.useState(false);
  const [checkoutOpen, setCheckoutOpen] = React.useState(false);
  const [profileOpen, setProfileOpen] = React.useState(false);
  const [profileOrdersOpen, setProfileOrdersOpen] = React.useState(false);
  const [authUser, setAuthUser] = React.useState(session || null);

  React.useEffect(() => {
    if (session) {
      setAuthUser(session);
    }
  }, [session]);

  const [selectedProduct, setSelectedProduct] = React.useState(null);
  const [modalQty, setModalQty] = React.useState(1);

  const cartCount = React.useMemo(() => {
    return cartItems.reduce((sum, item) => sum + (item.qty || 1), 0);
  }, [cartItems]);

  const [infoModal, setInfoModal] = React.useState(null);
  const emptyApplicationForm = { applicant_name: '', business_name: '', email: '', phone: '', address: '', category: '', leopard_courier_nearby: '', product_image_url: '', product_image_name: '', proposed_amount: '', investment_product: '', document_url: '', document_name: '', confirm_information: false, accept_terms: false, message: '' };
  const [applicationForm, setApplicationForm] = React.useState(emptyApplicationForm);
  const [applicationStatus, setApplicationStatus] = React.useState('');
  const [chatOpen, setChatOpen] = React.useState(false);
  const [chatMessage, setChatMessage] = React.useState('');
  const [chatSent, setChatSent] = React.useState(false);

  React.useEffect(() => {
    let active = true;
    const loadCategories = () => fetch('/api/categories?limit=100', { headers: { 'x-user-role': 'User' } })
      .then((response) => response.ok ? response.json() : { rows: [] })
      .then((data) => { if (active) setWebsiteCategories((Array.isArray(data.rows) ? data.rows : []).map((row) => ({ ...row, subcategories: Array.isArray(row.subcategories) ? row.subcategories : (() => { try { return JSON.parse(row.subcategories || '[]'); } catch { return []; } })() }))); })
      .catch(() => { if (active) setWebsiteCategories([]); });
    loadCategories();
    const interval = window.setInterval(loadCategories, 5000);
    return () => { active = false; window.clearInterval(interval); };
  }, []);

  React.useEffect(() => {
    let active = true;
    const loadProducts = () => fetch('/api/products?limit=500', { headers: { 'x-user-role': 'User' } })
      .then((response) => response.ok ? response.json() : { rows: [] })
      .then((data) => {
        if (!active) return;
        const rows = Array.isArray(data.rows) ? data.rows : [];
        setWebsiteProducts(rows.map((row) => ({
          ...row,
          id: row.id,
          title: row.name || 'Product',
          name: row.name || 'Product',
          image: row.image_url || 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600&q=80',
          gallery: [row.image_url, ...(() => { try { return (row.product_images ? JSON.parse(row.product_images) : []).map((item) => typeof item === 'string' ? item : item.url).filter(Boolean); } catch { return []; } })()].filter(Boolean).slice(0, 5),
          price: Number(row.discounted_price ?? row.base_price ?? row.actual_price ?? 0),
          originalPrice: Number(row.actual_price ?? row.base_price ?? 0),
          stock: Number(row.stock_qty || 0),
          category: row.category || 'All',
          subcategory: row.subcategory || '',
          colors: (() => { try { return JSON.parse(row.product_detail || '{}').colors || ''; } catch { return ''; } })(),
          sizes: (() => { try { return JSON.parse(row.product_detail || '{}').sizes || ''; } catch { return ''; } })(),
          status: Number(row.stock_qty || 0) === 0 ? 'Out of Stock' : (row.status || 'Active')
        })));
      })
      .catch(() => { if (active) setWebsiteProducts([]); });
    loadProducts();
    const interval = window.setInterval(loadProducts, 5000);
    return () => { active = false; window.clearInterval(interval); };
  }, []);

  const handleAddProductToCart = (product, qty = 1) => {
    if (!product) return;
    setCartItems((prev) => {
      const idx = prev.findIndex((item) => item.id === product.id);
      if (idx > -1) {
        const copy = [...prev];
        copy[idx] = { ...copy[idx], qty: (copy[idx].qty || 1) + qty };
        return copy;
      }
      return [...prev, { ...product, qty }];
    });
  };

  React.useEffect(() => {
    document.body.style.overflow = mobileMenuOpen || selectedProduct || checkoutOpen || infoModal || chatOpen ? 'hidden' : '';
    return () => {
      document.body.style.overflow = '';
    };
  }, [mobileMenuOpen, selectedProduct, checkoutOpen, infoModal, chatOpen]);

  React.useEffect(() => {
    const refreshVisibility = () => {
      try { setHiddenProductIds(JSON.parse(localStorage.getItem('apexiums-hidden-products') || '[]')); } catch { setHiddenProductIds([]); }
    };
    window.addEventListener('apexiums-product-visibility-changed', refreshVisibility);
    return () => window.removeEventListener('apexiums-product-visibility-changed', refreshVisibility);
  }, []);

  const visible = (list) => list.filter((p) => !hiddenProductIds.includes(p.id) && p.status !== 'Inactive' && p.status !== 'Out of Stock');
  const catalogProducts = websiteProducts.length ? websiteProducts : [...flashSaleProducts, ...productSections.flatMap((section) => section.products)];
  const filteredFlashSale = filterProducts(visible(catalogProducts), searchQuery, selectedCategory);
  const filteredSections = [{ title: 'All Products', products: filterProducts(visible(catalogProducts), searchQuery, selectedCategory) }];

  const allProductsList = React.useMemo(() => {
    const map = new Map();
    catalogProducts.forEach((p) => map.set(p.id, p));
    return Array.from(map.values());
  }, [catalogProducts]);

  function handleLogin(user) {
    setAuthUser(user);
    if (onLogin) onLogin(user);
    setLoginOpen(false);
    setProfileOpen(true);
  }

  const handleAccountClick = () => {
    const currentUser = authUser;

    if (currentUser && (isAdminRole(currentUser.role) || currentUser.loginType === 'admin')) {
      window.location.assign('/dashboard');
    } else if (currentUser) {
      setAuthUser(currentUser);
      setProfileOpen(true);
    } else {
      setLoginOpen(true);
    }
  };

  function handleLogout() {
    setAuthUser(null);
    if (onLogout) {
      onLogout();
    }
    setInfoModal({
      title: 'Logged Out',
      content: 'You have been successfully logged out of your Apexiums account.'
    });
  }

  const sideMenuOptions = [
    {
      label: authUser ? 'My Profile' : 'Login / Register',
      icon: authUser ? <User size={18} /> : <LogIn size={18} />,
      onClick: handleAccountClick
    },
    {
      label: 'My Orders',
      icon: <Package size={18} />,
      onClick: () => {
        if (!authUser) return setLoginOpen(true);
        setProfileOrdersOpen(true);
        setProfileOpen(true);
      }
    },
    {
      label: 'About',
      icon: <Info size={18} />,
      onClick: () =>
        setInfoModal({
          title: 'About Apexiums',
          content:
            'Apexiums Technologies is your premier online e-commerce marketplace offering high-quality fashion, electronics, gadgets, and daily essentials with fast delivery and guaranteed satisfaction.'
        })
    },
    {
      label: 'Become a Seller',
      icon: <Store size={18} />,
      onClick: () => {
        setApplicationStatus('');
        setInfoModal({
          title: 'Become a Seller',
          type: 'seller-application',
          content: 'Join our community of successful sellers and start growing your business today! By becoming a seller on Elistin, you gain access to thousands of daily active customers, secure payment processing, and reliable logistics support through our partner network. We provide you with the tools to manage your inventory, track your sales performance, and provide excellent service to your customers across the nation.'
        });
      }
    },
    {
      label: 'Become an Investor',
      icon: <Briefcase size={18} />,
      onClick: () =>
        setInfoModal({
          title: 'Become an Investor',
          type: 'investor-application',
          content:
            'Join the Elistin investment program and be part of our growing success. By investing in our curated product inventory, you contribute to the expansion of our premium retail network and earn competitive returns on your capital. We ensure transparent tracking of your investment performance and provide dedicated support for all our valued partners.'
        })
    },
    {
      label: 'Privacy Policy',
      icon: <ShieldCheck size={18} />,
      onClick: openPrivacyPolicy
    },
    {
      label: 'Help and Support',
      icon: <img src={customerSupportIcon} alt="" className="h-6 w-6 rounded-lg" />,
      onClick: () => openWhatsApp('Hello, I need assistance from Elistin customer support.')
    },
    {
      label: 'Logout',
      icon: <LogOut size={18} />,
      isLogout: true,
      onClick: handleLogout
    }
  ];

  return (
    <div
      className="flex min-h-screen flex-col text-slate-900 font-sans"
      style={{ backgroundColor: 'var(--brand-primary)' }}
    >
      <Header
        storeName={storeName}
        logoSrc={storeLogoSrc}
        authUser={authUser}
        cartCount={cartCount}
        onAccountClick={handleAccountClick}
        onCartClick={() => setCheckoutOpen(true)}
        onWishlistClick={() => {
          const el = document.getElementById('products-section');
          if (el) el.scrollIntoView({ behavior: 'smooth' });
        }}
        mobileMenuOpen={mobileMenuOpen}
        onMenuToggle={() => setMobileMenuOpen((value) => !value)}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        onSearchSubmit={(event) => event.preventDefault()}
        onSearchFocus={() => setMobileMenuOpen(false)}
      />

      {/* Main Content Card with Crisp White / Light Slate #F8F9FA */}
      <main className="relative z-10 flex-1 overflow-hidden rounded-t-[28px] bg-[#F8F9FA] pt-3 pb-24 shadow-[0_10px_24px_rgba(15,23,42,0.10)] sm:rounded-t-[36px] sm:pb-28 space-y-0">
        {categoryPage ? (
          <section className="mx-auto max-w-7xl px-3 sm:px-4 lg:px-6 py-5 space-y-4">
            <button type="button" onClick={() => { setCategoryPage(null); setSelectedCategory('All'); window.history.pushState({}, '', '/'); window.scrollTo({ top: 0, left: 0, behavior: 'auto' }); }} className="text-sm font-bold text-red-600">← Back to Home</button>
            {categoryPage === '__all_categories__' ? <><div className="rounded-2xl border border-slate-200 bg-white p-5"><h1 className="text-2xl font-black text-slate-900">All Categories</h1><p className="mt-1 text-sm text-slate-500">Browse every category available in our store.</p></div><div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">{websiteCategories.map((category) => <button key={category.id || category.name} type="button" onClick={() => { setSelectedCategory(category.name); setCategoryPage(category.name); window.history.pushState({}, '', `/category/${encodeURIComponent(category.name)}`); }} className="group rounded-2xl border border-slate-200 bg-white p-4 text-center shadow-sm transition hover:-translate-y-0.5 hover:border-red-300 hover:shadow-md"><div className="mx-auto h-20 w-20 overflow-hidden rounded-full border-2 border-slate-100 bg-slate-50 p-0.5 group-hover:border-red-200">{category.image_url || category.image ? <img src={category.image_url || category.image} alt={category.name} className="h-full w-full rounded-full object-cover" /> : <span className="flex h-full items-center justify-center text-2xl font-black text-slate-400">{category.name?.charAt(0)}</span>}</div><p className="mt-3 text-sm font-black text-slate-800 group-hover:text-red-600">{category.name}</p></button>)}</div></> : <><div className="rounded-2xl bg-white border border-slate-200 p-5">
              <h1 className="text-2xl font-black text-slate-900">{categoryPage}</h1>
              <p className="mt-1 text-sm text-slate-500">Products in {categoryPage} category</p>
              {websiteCategories.find((c) => c.name === categoryPage)?.subcategories?.length ? <div className="mt-4 flex flex-wrap gap-2">{websiteCategories.find((c) => c.name === categoryPage).subcategories.map((sub) => <button key={sub} type="button" onClick={() => setSelectedCategory(sub)} className="rounded-full bg-slate-100 px-3 py-1.5 text-xs font-bold hover:bg-red-50 hover:text-red-600">{sub}</button>)}</div> : null}
            </div>
            <ProductGrid sections={filteredSections} selectedCategory={selectedCategory} onSelectCategory={setSelectedCategory} onSelectProduct={(p) => { setSelectedProduct(p); setModalQty(1); }} onAddToCart={(p) => handleAddProductToCart(p, 1)} /></>}
          </section>
        ) : <>
        <HeroBanner slides={heroSlides} promoBanners={promoBanners} />
        <CategoryGrid
          categories={websiteCategories}
          selectedCategory={selectedCategory}
          onSelectCategory={(cat) => { setSelectedCategory(cat); if (cat !== 'All') { setCategoryPage(cat); window.history.pushState({}, '', `/category/${encodeURIComponent(cat)}`); } }}
          onViewAll={() => { setCategoryPage('__all_categories__'); window.history.pushState({}, '', '/categories'); window.scrollTo({ top: 0, left: 0, behavior: 'auto' }); }}
        />
        <FlashSale
          products={filteredFlashSale}
          onProductClick={(p) => { setSelectedProduct(p); setModalQty(1); }}
          onAddToCart={(p) => handleAddProductToCart(p, 1)}
        />
        </>}
      </main>

      <Footer
        sections={footerSections}
        paymentMethods={paymentMethods}
        storeName={storeName}
        logoSrc={storeLogoSrc}
        categories={websiteCategories}
        onCategoryClick={(categoryName) => {
          setSelectedCategory(categoryName);
          setCategoryPage(categoryName);
          window.history.pushState({}, '', `/category/${encodeURIComponent(categoryName)}`);
          window.scrollTo({ top: 0, left: 0, behavior: 'smooth' });
        }}
        onAdminClick={() => setLoginOpen(true)}
      />

      {!selectedProduct ? (
        <BottomNav
          cartCount={cartCount}
          isCartOpen={checkoutOpen}
          isProfileOpen={profileOpen}
          onCartClick={() => {
            setProfileOpen(false);
            setCheckoutOpen(true);
          }}
          onHomeClick={() => {
            setProfileOpen(false);
            setCheckoutOpen(false);
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          onAccountClick={() => {
            setCheckoutOpen(false);
            handleAccountClick();
          }}
          onWishlistClick={() => {
            setProfileOpen(false);
            setCheckoutOpen(false);
            const el = document.getElementById('products-section');
            if (el) el.scrollIntoView({ behavior: 'smooth' });
          }}
          onSupportClick={() => {
            setProfileOpen(false);
            setCheckoutOpen(false);
            openWhatsApp('Hello, I need assistance from Elistin customer support.');
          }}
          onChatClick={() => {
            setProfileOpen(false);
            setCheckoutOpen(false);
            openWhatsApp('Hello, I need assistance from Elistin customer support.');
          }}
        />
      ) : null}

      {/* Slide-out Menu Drawer */}
      {mobileMenuOpen ? (
        <div className="fixed inset-0 z-[120] bg-slate-950/60 backdrop-blur-xs transition-opacity">
          <button
            type="button"
            aria-label="Close menu overlay"
            className="absolute inset-0 h-full w-full cursor-pointer"
            onClick={() => setMobileMenuOpen(false)}
          />
          <aside className="absolute left-0 top-0 z-10 flex h-[100dvh] w-[85%] max-w-sm flex-col justify-between overflow-y-auto overscroll-contain bg-white p-5 pb-32 shadow-2xl">
            <div>
              {/* Drawer Header */}
              <div className="flex items-center justify-between border-b border-slate-100 pb-4">
                <div className="flex items-center gap-2.5">
                  <div className="flex h-10 w-10 items-center justify-center overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-2xs">
                    <img src={storeLogoSrc} alt={`${storeName} logo`} className="h-full w-full object-cover" />
                  </div>
                  <div>
                    <h2 className="font-black text-slate-900 text-base leading-tight">{storeName}</h2>
                    <p className="text-[11px] font-medium text-slate-500">Super Online Marketplace</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setMobileMenuOpen(false)}
                  className="flex h-9 w-9 items-center justify-center rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600 transition cursor-pointer"
                >
                  <X size={18} />
                </button>
              </div>

              {/* User Account Banner with Red Gradient */}
              <div className="mt-4 rounded-2xl bg-gradient-to-r from-[#E8262A] to-[#E8262A] p-3.5 text-white shadow-sm flex items-center justify-between">
                <div>
                  <p className="text-[11px] font-medium text-red-100">Welcome to {storeName}</p>
                  <p className="text-xs sm:text-sm font-bold mt-0.5 truncate max-w-[170px]">
                    {authUser ? authUser.name || authUser.email : 'Guest Account'}
                  </p>
                </div>
                {!authUser ? (
                  <button
                    type="button"
                    onClick={() => {
                      setMobileMenuOpen(false);
                      setLoginOpen(true);
                    }}
                    className="px-3 py-1.5 rounded-xl bg-white text-[#E8262A] font-bold text-xs shadow-2xs hover:bg-red-50 transition cursor-pointer shrink-0"
                  >
                    Login
                  </button>
                ) : (
                  <span className="px-2 py-0.5 rounded-md bg-white/20 text-[10px] font-bold backdrop-blur-xs">
                    Signed In
                  </span>
                )}
              </div>

              {/* Menu Options List */}
              <div className="mt-4 space-y-1 pb-6">
                {sideMenuOptions.map((item) => (
                  <button
                    key={item.label}
                    type="button"
                    onClick={() => {
                      setMobileMenuOpen(false);
                      item.onClick();
                    }}
                    className={`w-full flex items-center justify-between px-3 py-2.5 rounded-2xl text-xs font-bold transition-all cursor-pointer ${
                      item.isLogout
                        ? 'text-red-600 hover:bg-red-50 mt-3 mb-4 border border-red-100'
                        : 'text-slate-800 hover:bg-red-50/60 hover:text-[#E8262A]'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <span
                        className={`flex h-8 w-8 items-center justify-center rounded-xl ${
                          item.isLogout
                            ? 'bg-red-100 text-red-600'
                            : 'bg-red-50 text-[#E8262A]'
                        }`}
                      >
                        {item.icon}
                      </span>
                      <span>{item.label}</span>
                    </div>
                    <ChevronRight size={16} className="text-slate-400" />
                  </button>
                ))}
              </div>
            </div>
          </aside>
        </div>
      ) : null}

      {/* Dynamic Info Popup Modal */}
      {chatOpen ? <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-950/60 p-4 backdrop-blur-sm"><form onSubmit={async(e)=>{e.preventDefault();if(!chatMessage.trim())return;const chat={customerName:authUser?.name||'Guest Customer',message:chatMessage.trim()};try{const response=await fetch('/api/chats',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({sender_name:chat.customerName,sender_type:'Customer',subject:'Customer Support',message:chat.message,status:'Open'})});if(!response.ok)throw new Error()}catch{return;}setChatMessage('');setChatSent(true)}} className="w-full max-w-md rounded-3xl bg-white p-6 shadow-2xl"><div className="flex items-center justify-between border-b pb-3"><div className="flex items-center gap-2"><Headphones className="text-red-600" size={20}/><h3 className="font-black">Chat with Support</h3></div><button type="button" onClick={()=>setChatOpen(false)}><X size={18}/></button></div>{chatSent&&<div className="mt-4 rounded-xl bg-emerald-50 p-3 text-xs font-bold text-emerald-700">Message sent. Admin will reply from Customer Chats.</div>}<label className="mt-4 block text-xs font-bold">Your question<textarea required rows="5" value={chatMessage} onChange={(e)=>setChatMessage(e.target.value)} placeholder="Write your question here..." className="mt-1 w-full rounded-xl border p-3 font-medium outline-none focus:border-red-500"/></label><button className="mt-4 w-full rounded-xl bg-red-600 py-3 text-xs font-black text-white">Send Message</button></form></div> : null}

      {infoModal ? (
        <div className="fixed inset-0 z-[150] flex items-center justify-center bg-slate-950/60 p-3 pb-[calc(0.75rem+env(safe-area-inset-bottom))] sm:p-4 backdrop-blur-xs">
          <div className={`w-full ${infoModal.type ? 'max-w-xl' : 'max-w-sm'} max-h-[92vh] overflow-y-auto rounded-3xl bg-white p-5 sm:p-6 shadow-2xl border border-slate-100 text-slate-900 animate-in fade-in zoom-in-95 duration-200`}>
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-red-50 text-[#E8262A]">
                  <Info size={20} />
                </div>
                <h3 className="font-extrabold text-base text-[#1E1E1E]">{infoModal.title}</h3>
              </div>
              <button
                type="button"
                onClick={() => setInfoModal(null)}
                className="flex h-8 w-8 items-center justify-center rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 transition cursor-pointer"
              >
                <X size={16} />
              </button>
            </div>

            <p className={`mt-4 text-xs sm:text-sm leading-relaxed font-medium ${infoModal.type ? 'rounded-2xl bg-[#FF3D50] p-5 text-white' : 'text-slate-600'}`}>{infoModal.content}</p>

            {infoModal.type ? <form className="mt-4 space-y-3" onSubmit={async (event) => {
              event.preventDefault(); setApplicationStatus('Submitting...');
              const resource = infoModal.type === 'seller-application' ? 'seller_applications' : 'investor_applications';
              const payload = infoModal.type === 'seller-application' ? { applicant_name: applicationForm.applicant_name, business_name: applicationForm.business_name || `${applicationForm.applicant_name}'s Store`, email: applicationForm.email, phone: applicationForm.phone, address: applicationForm.address, category: applicationForm.category, leopard_courier_nearby: applicationForm.leopard_courier_nearby, product_image_url: applicationForm.product_image_url, message: applicationForm.message, status: 'Pending' } : { applicant_name: applicationForm.applicant_name, email: applicationForm.email, phone: applicationForm.phone, address: applicationForm.address, proposed_amount: Number(applicationForm.proposed_amount || 0), investment_product: applicationForm.investment_product, document_url: applicationForm.document_url, message: applicationForm.message, status: 'Pending' };
              if (infoModal.type && (!applicationForm.confirm_information || !applicationForm.accept_terms)) { setApplicationStatus('Please confirm the information and accept the Terms and Conditions.'); return; }
              try { const response = await fetch(`/api/${resource}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) }); if (!response.ok) throw new Error('Application could not be submitted.'); setApplicationStatus('Application submitted successfully. Our team will review it.'); setApplicationForm(emptyApplicationForm); } catch (error) { setApplicationStatus(error.message); }
            }}>
              {infoModal.type === 'investor-application' ? <>
                {[['applicant_name','Name','Enter your full name'],['phone','Contact','Enter your contact number'],['email','Email','Enter your email address'],['address','Full Address','Enter your full residential address']].map(([key,label,placeholder]) => <label key={key} className="block text-xs font-black text-slate-900">{label}<input required type={key === 'email' ? 'email' : 'text'} value={applicationForm[key]} onChange={(event) => setApplicationForm({ ...applicationForm, [key]: event.target.value })} placeholder={placeholder} className="mt-1.5 w-full rounded-2xl border-0 bg-slate-50 px-4 py-3.5 text-sm font-medium outline-none focus:ring-2 focus:ring-red-300"/></label>)}
                <label className="block text-xs font-black text-slate-900">How much money do you want to invest?<input required type="number" min="1" value={applicationForm.proposed_amount} onChange={(event) => setApplicationForm({ ...applicationForm, proposed_amount: event.target.value })} placeholder="e.g. Rs 500,000" className="mt-1.5 w-full rounded-2xl border-0 bg-slate-50 px-4 py-3.5 text-sm font-medium outline-none focus:ring-2 focus:ring-red-300"/></label>
                <label className="block text-xs font-black text-slate-900">On which product do you want to invest?<input required value={applicationForm.investment_product} onChange={(event) => setApplicationForm({ ...applicationForm, investment_product: event.target.value })} placeholder="e.g. Electronics, Apparel" className="mt-1.5 w-full rounded-2xl border-0 bg-slate-50 px-4 py-3.5 text-sm font-medium outline-none focus:ring-2 focus:ring-red-300"/></label>
                <label className="block text-xs font-black text-slate-900">Upload ID or Document Picture<span className="mt-1.5 flex min-h-28 cursor-pointer flex-col items-center justify-center rounded-2xl border border-slate-200 bg-slate-50 px-4 text-center text-slate-400 transition hover:border-red-300"><Upload size={22}/><span className="mt-2 font-semibold">{applicationForm.document_name || 'Tap to upload image'}</span></span><input required type="file" accept="image/*" onChange={(event) => { const file = event.target.files?.[0]; if (!file) return; const reader = new FileReader(); reader.onload = () => setApplicationForm({ ...applicationForm, document_url: reader.result, document_name: file.name }); reader.readAsDataURL(file); }} className="sr-only"/></label>
                <label className="block text-xs font-black text-slate-900">Additional Details (Optional)<textarea rows="3" value={applicationForm.message} onChange={(event) => setApplicationForm({ ...applicationForm, message: event.target.value })} placeholder="Tell us anything else about your investment proposal" className="mt-1.5 w-full rounded-2xl border-0 bg-slate-50 px-4 py-3 text-sm font-medium outline-none focus:ring-2 focus:ring-red-300"/></label>
                <div className="space-y-3 border-t border-slate-100 pt-3"><label className="flex cursor-pointer items-start gap-3 text-xs font-medium text-slate-700"><input type="checkbox" checked={applicationForm.confirm_information} onChange={(event) => setApplicationForm({ ...applicationForm, confirm_information: event.target.checked })} className="mt-0.5 h-4 w-4 accent-[#E8262A]"/><span>The information provided is correct.</span></label><label className="flex cursor-pointer items-start gap-3 text-xs font-medium text-slate-700"><input type="checkbox" checked={applicationForm.accept_terms} onChange={(event) => setApplicationForm({ ...applicationForm, accept_terms: event.target.checked })} className="mt-0.5 h-4 w-4 accent-[#E8262A]"/><span>I agree to the Terms and Conditions.</span></label></div>
              </> : <>
                {[['applicant_name','Name','Enter your full name'],['phone','Contact','Enter your contact number'],['email','Email','Enter your email address'],['address','Full Address','Enter your shop or warehouse address'],['category','Which product do you want to sell?','e.g. Handmade Shoes, Organic Honey']].map(([key,label,placeholder]) => <label key={key} className="block text-xs font-black text-slate-900">{label}<input required type={key === 'email' ? 'email' : 'text'} value={applicationForm[key]} onChange={(event) => setApplicationForm({ ...applicationForm, [key]: event.target.value })} placeholder={placeholder} className="mt-1.5 w-full rounded-2xl border-0 bg-slate-50 px-4 py-3.5 text-sm font-medium outline-none focus:ring-2 focus:ring-red-300"/></label>)}
                <fieldset className="text-xs font-black text-slate-900"><legend>Is Leopard Courier office near you?</legend><div className="mt-3 flex gap-8"><label className="flex items-center gap-2 font-medium"><input required type="radio" name="leopard-courier" value="Yes" checked={applicationForm.leopard_courier_nearby === 'Yes'} onChange={(event) => setApplicationForm({ ...applicationForm, leopard_courier_nearby: event.target.value })} className="h-4 w-4 accent-[#E8262A]"/>Yes</label><label className="flex items-center gap-2 font-medium"><input required type="radio" name="leopard-courier" value="No" checked={applicationForm.leopard_courier_nearby === 'No'} onChange={(event) => setApplicationForm({ ...applicationForm, leopard_courier_nearby: event.target.value })} className="h-4 w-4 accent-[#E8262A]"/>No</label></div></fieldset>
                <label className="block text-xs font-black text-slate-900">Upload Product Picture<span className="mt-1.5 flex min-h-32 cursor-pointer flex-col items-center justify-center rounded-2xl border border-slate-200 bg-slate-50 px-4 text-center text-slate-400 transition hover:border-red-300"><Upload size={24}/><span className="mt-2 font-semibold">{applicationForm.product_image_name || 'Tap to upload image'}</span></span><input required type="file" accept="image/*" onChange={(event) => { const file = event.target.files?.[0]; if (!file) return; const reader = new FileReader(); reader.onload = () => setApplicationForm({ ...applicationForm, product_image_url: reader.result, product_image_name: file.name }); reader.readAsDataURL(file); }} className="sr-only"/></label>
                <label className="block text-xs font-black text-slate-900">Business / Store Name (Optional)<input value={applicationForm.business_name} onChange={(event) => setApplicationForm({ ...applicationForm, business_name: event.target.value })} placeholder="Enter your store name" className="mt-1.5 w-full rounded-2xl border-0 bg-slate-50 px-4 py-3.5 text-sm font-medium outline-none focus:ring-2 focus:ring-red-300"/></label>
                <label className="block text-xs font-black text-slate-900">Additional Details (Optional)<textarea rows="3" value={applicationForm.message} onChange={(event) => setApplicationForm({ ...applicationForm, message: event.target.value })} placeholder="Tell us anything else about your products" className="mt-1.5 w-full rounded-2xl border-0 bg-slate-50 px-4 py-3 text-sm font-medium outline-none focus:ring-2 focus:ring-red-300"/></label>
                <div className="space-y-3 border-t border-slate-100 pt-3"><label className="flex cursor-pointer items-start gap-3 text-xs font-medium text-slate-700"><input type="checkbox" checked={applicationForm.confirm_information} onChange={(event) => setApplicationForm({ ...applicationForm, confirm_information: event.target.checked })} className="mt-0.5 h-4 w-4 accent-[#E8262A]"/><span>The information provided is correct.</span></label><label className="flex cursor-pointer items-start gap-3 text-xs font-medium text-slate-700"><input type="checkbox" checked={applicationForm.accept_terms} onChange={(event) => setApplicationForm({ ...applicationForm, accept_terms: event.target.checked })} className="mt-0.5 h-4 w-4 accent-[#E8262A]"/><span>I agree to the Terms and Conditions.</span></label></div>
              </>}
              {applicationStatus ? <p className="text-xs font-bold text-emerald-600">{applicationStatus}</p> : null}
              <button disabled={infoModal.type && (!applicationForm.confirm_information || !applicationForm.accept_terms || (infoModal.type === 'investor-application' ? !applicationForm.document_url : !applicationForm.product_image_url || !applicationForm.leopard_courier_nearby))} className="sticky bottom-0 z-10 w-full rounded-xl bg-[#E8262A] py-3 text-xs font-bold text-white shadow-[0_-8px_18px_rgba(255,255,255,0.95)] disabled:cursor-not-allowed disabled:bg-slate-300">Submit Form</button>
            </form> : null}

            {!infoModal.type ? <div className="mt-6 flex justify-end">
              <button
                type="button"
                onClick={() => setInfoModal(null)}
                className="w-full py-2.5 rounded-xl bg-[#E8262A] hover:bg-red-700 text-white font-bold text-xs shadow-xs transition active:scale-95 cursor-pointer"
              >
                Got It
              </button>
            </div> : null}
          </div>
        </div>
      ) : null}

      {/* Interactive Product Detail Modal */}
      {selectedProduct ? (
        <ProductDetailsModal
          product={selectedProduct}
          allProducts={allProductsList}
          storeName={storeName}
          cartCount={cartCount}
          onOpenCart={() => {
            setSelectedProduct(null);
            setCheckoutOpen(true);
          }}
          onSelectProduct={(p) => {
            setSelectedProduct(p);
            setModalQty(1);
          }}
          onClose={() => setSelectedProduct(null)}
          onAddToCart={(qty) => {
            handleAddProductToCart(selectedProduct, qty);
          }}
          onBuyNow={(qty) => {
            handleAddProductToCart(selectedProduct, qty);
            setSelectedProduct(null);
            setCheckoutOpen(true);
          }}
        />
      ) : null}

      <LoginModal
        open={loginOpen}
        onClose={() => setLoginOpen(false)}
        onLogin={handleLogin}
        storeName={storeName}
        logoSrc={storeLogoSrc}
      />

      <CheckoutModal
        open={checkoutOpen}
        onClose={() => setCheckoutOpen(false)}
        storeName={storeName}
        logoSrc={storeLogoSrc}
        cartItems={cartItems}
        customerEmail={authUser?.email || ''}
        onUpdateQty={(id, delta) => {
          setCartItems((prev) =>
            prev
              .map((item) =>
                item.id === id ? { ...item, qty: Math.max(1, (item.qty || 1) + delta) } : item
              )
          );
        }}
        onRemoveItem={(id) => {
          setCartItems((prev) => prev.filter((item) => item.id !== id));
        }}
        onOrderPlaced={() => setCartItems([])}
      />

      {profileOpen ? (
        <div className="fixed inset-0 z-[90] bg-white overflow-y-auto animate-in fade-in zoom-in-95 duration-200">
          <UserProfileView
            session={authUser}
            initialOrders={profileOrdersOpen}
            onBack={() => { setProfileOpen(false); setProfileOrdersOpen(false); }}
            onOpenLogin={() => {
              setProfileOpen(false);
              setLoginOpen(true);
            }}
            onLogout={() => {
              handleLogout();
              setProfileOpen(false);
              setProfileOrdersOpen(false);
            }}
            onNavigateTab={(tab, filter) => {
              setProfileOpen(false);
              setCheckoutOpen(true);
            }}
          />
        </div>
      ) : null}
    </div>
  );
}
