import React from 'react';
import { Headphones, Home, ShoppingCart, User } from 'lucide-react';

export default function BottomNav({ onCartClick, onAccountClick, onSupportClick, cartCount = 0 }) {
  const [activeTab, setActiveTab] = React.useState('Home');

  const handleHome = () => {
    setActiveTab('Home');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSupport = () => {
    setActiveTab('Support');
    if (onSupportClick) {
      onSupportClick();
    } else {
      window.open('https://wa.me/923000000000?text=Hello%20Apexiums%20Super%20Store%20Support', '_blank');
    }
  };

  const handleCart = () => {
    setActiveTab('Cart');
    if (onCartClick) onCartClick();
  };

  const handleAccount = () => {
    setActiveTab('Account');
    if (onAccountClick) onAccountClick();
  };

  const navItems = [
    { label: 'Home', icon: Home, action: handleHome },
    { label: 'Support', icon: Headphones, action: handleSupport },
    { label: 'Cart', icon: ShoppingCart, action: handleCart, badge: cartCount },
    { label: 'Account', icon: User, action: handleAccount }
  ];

  return (
    <nav className="fixed inset-x-0 bottom-0 z-50 border-t border-slate-200/80 bg-white/95 backdrop-blur-md shadow-lg w-full">
      <div className="mx-auto max-w-7xl grid grid-cols-4 gap-1 px-2 py-1.5">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.label;

          return (
            <button
              key={item.label}
              type="button"
              onClick={item.action}
              className={`relative flex min-h-11 flex-col items-center justify-center gap-0.5 rounded-xl transition-all active:scale-95 cursor-pointer ${
                isActive
                  ? 'text-emerald-600 font-bold'
                  : 'text-slate-500 hover:text-slate-800 font-medium'
              }`}
            >
              <div className="relative">
                <Icon size={19} className={isActive ? 'text-emerald-600' : 'text-slate-500'} />
                {item.badge !== undefined && item.badge !== null && item.badge > 0 ? (
                  <span className="absolute -top-1.5 -right-3 flex h-4 min-w-4 items-center justify-center rounded-full bg-emerald-600 px-1 text-[9px] font-black text-white ring-2 ring-white shadow-2xs">
                    {item.badge}
                  </span>
                ) : null}
              </div>
              <span className="text-[10px] tracking-tight">{item.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}


