import React from 'react';
import { Heart, Home, MessageSquare, ShoppingCart, User } from 'lucide-react';

export default function BottomNav({ onCartClick, onAccountClick, onWishlistClick, onChatClick, cartCount = 0 }) {
  const [activeTab, setActiveTab] = React.useState('Home');

  const handleHome = () => {
    setActiveTab('Home');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleWishlist = () => {
    setActiveTab('Wishlist');
    if (onWishlistClick) {
      onWishlistClick();
    } else {
      const el = document.getElementById('products-section');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleCart = () => {
    setActiveTab('Cart');
    if (onCartClick) onCartClick();
  };

  const handleChat = () => {
    setActiveTab('Chat');
    if (onChatClick) {
      onChatClick();
    } else {
      window.open('https://wa.me/923000000000?text=Hello%20Support', '_blank');
    }
  };

  const handleProfile = () => {
    setActiveTab('Profile');
    if (onAccountClick) onAccountClick();
  };

  const navItems = [
    { label: 'Home', icon: Home, action: handleHome },
    { label: 'Wishlist', icon: Heart, action: handleWishlist },
    { label: 'Cart', icon: ShoppingCart, action: handleCart, badge: cartCount },
    { label: 'Chat', icon: MessageSquare, action: handleChat },
    { label: 'Profile', icon: User, action: handleProfile }
  ];

  return (
    <nav className="fixed inset-x-0 bottom-0 z-50 border-t border-slate-200/80 bg-white/95 backdrop-blur-lg shadow-lg">
      <div className="mx-auto max-w-lg grid grid-cols-5 gap-1 px-2 py-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.label;

          return (
            <button
              key={item.label}
              type="button"
              onClick={item.action}
              className={`relative flex flex-col items-center justify-center py-1 transition-all active:scale-95 cursor-pointer ${
                isActive
                  ? 'text-[#E8262A] font-extrabold'
                  : 'text-slate-500 hover:text-slate-800 font-medium'
              }`}
            >
              <div className="relative">
                <Icon
                  size={20}
                  className={`transition-transform duration-200 ${
                    isActive ? 'scale-110 text-[#E8262A]' : 'text-slate-500'
                  }`}
                />
                {item.badge !== undefined && item.badge !== null && item.badge > 0 ? (
                  <span className="absolute -top-1.5 -right-2.5 flex h-4 min-w-[16px] items-center justify-center rounded-full bg-[#E8262A] px-1 text-[9px] font-black text-white ring-2 ring-white shadow-xs">
                    {item.badge}
                  </span>
                ) : null}
              </div>
              <span className="text-[10px] tracking-tight mt-1">{item.label}</span>
              {isActive ? (
                <span className="mt-0.5 h-1 w-1 rounded-full bg-[#E8262A]" />
              ) : null}
            </button>
          );
        })}
      </div>
    </nav>
  );
}



