import React from 'react';
import Header from './Header';
import CategoryNav from './CategoryNav';
import HeroBanner from './HeroBanner';
import FlashSale from './FlashSale';
import CategoryGrid from './CategoryGrid';
import ProductGrid from './ProductGrid';
import Footer from './Footer';
import BottomNav from './BottomNav';
import LoginModal from './LoginModal';
import CheckoutModal from './CheckoutModal';
import ProductDetailsModal from './ProductDetailsModal';
import { Heart, Minus, Plus, ShieldCheck, ShoppingBag, ShoppingCart, Truck, X } from 'lucide-react';
import {
  categories,
  footerSections,
  flashSaleProducts,
  heroSlides,
  mainNav,
  paymentMethods,
  productSections,
  promoBanners,
  storeLogoSrc,
  storeName,
  topLinks
} from '../data/storeData';

function matchesCategory(product, cat) {
  if (!cat || cat === 'All') return true;
  const c = cat.toLowerCase();
  const pCat = (product.category || '').toLowerCase();
  const pTitle = (product.title || '').toLowerCase();

  if (pCat.includes(c) || pTitle.includes(c)) return true;

  if (c === 'fashion' || c === 'clothes' || c === 'shirts') {
    return (
      pCat.includes('fashion') ||
      pCat.includes('shirt') ||
      pCat.includes('cloth') ||
      pCat.includes('accessor') ||
      pTitle.includes('tee') ||
      pTitle.includes('shirt') ||
      pTitle.includes('sneaker') ||
      pTitle.includes('backpack') ||
      pTitle.includes('hoodie')
    );
  }
  if (c === 'electronics' || c === 'mobiles' || c === 'audio' || c === 'gaming' || c === 'laptops') {
    return (
      pCat.includes('electr') ||
      pCat.includes('audio') ||
      pCat.includes('gamin') ||
      pCat.includes('laptop') ||
      pTitle.includes('earbud') ||
      pTitle.includes('watch') ||
      pTitle.includes('phone') ||
      pTitle.includes('tv') ||
      pTitle.includes('controller') ||
      pTitle.includes('camera') ||
      pTitle.includes('keyboard') ||
      pTitle.includes('speaker')
    );
  }
  if (c === 'home & living' || c === 'home' || c === 'decor' || c === 'appliances') {
    return (
      pCat.includes('home') ||
      pCat.includes('decor') ||
      pCat.includes('appliance') ||
      pTitle.includes('lamp') ||
      pTitle.includes('chair') ||
      pTitle.includes('art') ||
      pTitle.includes('desk')
    );
  }
  if (c === 'shoes') {
    return (
      pCat.includes('shoe') ||
      pTitle.includes('shoe') ||
      pTitle.includes('sneaker')
    );
  }
  if (c === 'watches' || c === 'watch') {
    return pCat.includes('watch') || pTitle.includes('watch');
  }
  if (c === 'health & beauty' || c === 'beauty' || c === 'health') {
    return pCat.includes('beaut') || pCat.includes('health') || pTitle.includes('skin') || pTitle.includes('face') || pTitle.includes('fragrance');
  }
  if (c === 'sports' || c === 'fitness') {
    return pCat.includes('sport') || pCat.includes('fitn') || pTitle.includes('shoe') || pTitle.includes('mat');
  }

  return false;
}

function filterProducts(list, query, cat) {
  let result = list;
  if (cat && cat !== 'All') {
    result = result.filter((p) => matchesCategory(p, cat));
  }
  const needle = query.trim().toLowerCase();
  if (!needle) return result;
  return result.filter((product) =>
    [product.title, product.category, product.badge].some((field) => (field || '').toLowerCase().includes(needle))
  );
}

export default function StorefrontHome({ onLogin }) {
  const [searchQuery, setSearchQuery] = React.useState('');
  const [selectedCategory, setSelectedCategory] = React.useState('All');
  const [cartItems, setCartItems] = React.useState([]);
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);
  const [loginOpen, setLoginOpen] = React.useState(false);
  const [checkoutOpen, setCheckoutOpen] = React.useState(false);
  const [authUser, setAuthUser] = React.useState(null);
  const [selectedProduct, setSelectedProduct] = React.useState(null);
  const [modalQty, setModalQty] = React.useState(1);

  const cartCount = React.useMemo(() => {
    return cartItems.reduce((sum, item) => sum + (item.qty || 1), 0);
  }, [cartItems]);

  const handleAddProductToCart = (product, qty = 1) => {
    if (!product) return;
    setCartItems((prev) => {
      const idx = prev.findIndex((item) => item.id === product.id);
      if (idx > -1) {
        const copy = [...prev];
        copy[idx] = { ...copy[idx], qty: (copy[idx].qty || 1) + qty };
        return copy;
      }
      return [...prev, { ...product, qty }];
    });
  };

  React.useEffect(() => {
    document.body.style.overflow = mobileMenuOpen || selectedProduct || checkoutOpen ? 'hidden' : '';
    return () => {
      document.body.style.overflow = '';
    };
  }, [mobileMenuOpen, selectedProduct, checkoutOpen]);

  const filteredFlashSale = filterProducts(flashSaleProducts, searchQuery, selectedCategory);
  const filteredSections = productSections.map((section) => ({
    ...section,
    products: filterProducts(section.products, searchQuery, selectedCategory)
  }));

  const allProductsList = React.useMemo(() => {
    const map = new Map();
    flashSaleProducts.forEach((p) => map.set(p.id, p));
    productSections.forEach((s) => s.products.forEach((p) => map.set(p.id, p)));
    return Array.from(map.values());
  }, []);

  function handleLogin(user) {
    setAuthUser(user);
    onLogin(user);
  }

  return (
    <div className="flex flex-col min-h-screen bg-slate-100 text-slate-900 font-sans">
      <Header
        storeName={storeName}
        logoSrc={storeLogoSrc}
        authUser={authUser}
        cartCount={cartCount}
        onAccountClick={() => setLoginOpen(true)}
        onAdminClick={() => setLoginOpen(true)}
        onCartClick={() => setCheckoutOpen(true)}
        onWishlistClick={() => {
          const el = document.getElementById('products-section');
          if (el) el.scrollIntoView({ behavior: 'smooth' });
        }}
        mobileMenuOpen={mobileMenuOpen}
        onMenuToggle={() => setMobileMenuOpen((value) => !value)}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        onSearchSubmit={(event) => event.preventDefault()}
        onSearchFocus={() => setMobileMenuOpen(false)}
      />

      {/* Removed CategoryNav line as requested */}

      {mobileMenuOpen ? (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs lg:hidden">
          <button
            type="button"
            aria-label="Close menu overlay"
            className="absolute inset-0 h-full w-full"
            onClick={() => setMobileMenuOpen(false)}
          />
          <aside className="absolute left-0 top-0 h-full w-[85%] max-w-sm overflow-y-auto bg-white p-5 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-100 pb-4">
              <img src={storeLogoSrc} alt={storeName} loading="lazy" className="h-9 w-auto object-contain" />
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setMobileMenuOpen(false);
                    setLoginOpen(true);
                  }}
                  className="inline-flex min-h-10 items-center rounded-xl bg-emerald-600 px-4 text-xs font-bold text-white shadow-xs"
                >
                  Sign In
                </button>
                <button
                  type="button"
                  onClick={() => setMobileMenuOpen(false)}
                  className="inline-flex h-9 w-9 items-center justify-center rounded-xl border border-slate-200 text-slate-600"
                >
                  <X size={18} />
                </button>
              </div>
            </div>

            <div className="mt-4 grid gap-2">
              {topLinks.map((link) => (
                <a
                  key={link}
                  href="#"
                  className="flex min-h-10 items-center rounded-xl bg-slate-50 px-4 text-xs font-semibold text-slate-700"
                >
                  {link}
                </a>
              ))}
            </div>

            <div className="mt-6">
              <p className="text-[11px] font-bold uppercase tracking-wider text-emerald-700">Categories</p>
              <div className="mt-2 grid gap-2">
                {mainNav.map((item) => (
                  <div key={item.label} className="rounded-xl border border-slate-200/80 p-3">
                    <h3 className="font-bold text-slate-900 text-xs">{item.label}</h3>
                    <div className="mt-2 flex flex-wrap gap-1.5">
                      {item.items.map((subItem) => (
                        <span key={subItem} className="rounded-md bg-emerald-50 px-2.5 py-1 text-[11px] font-semibold text-emerald-800">
                          {subItem}
                        </span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </aside>
        </div>
      ) : null}

      <main className="flex-1 pb-24 sm:pb-28 space-y-2 sm:space-y-3 lg:space-y-4">
        <HeroBanner slides={heroSlides} promoBanners={promoBanners} />
        <CategoryGrid
          categories={categories}
          selectedCategory={selectedCategory}
          onSelectCategory={(cat) => setSelectedCategory(cat)}
        />
        <FlashSale
          products={filteredFlashSale}
          onProductClick={(p) => { setSelectedProduct(p); setModalQty(1); }}
          onAddToCart={(p) => handleAddProductToCart(p, 1)}
        />
        <ProductGrid
          sections={filteredSections}
          selectedCategory={selectedCategory}
          onSelectCategory={(cat) => setSelectedCategory(cat)}
          onSelectProduct={(p) => { setSelectedProduct(p); setModalQty(1); }}
          onAddToCart={(p) => handleAddProductToCart(p, 1)}
        />
      </main>

      <Footer sections={footerSections} paymentMethods={paymentMethods} storeName={storeName} logoSrc={storeLogoSrc} onAdminClick={() => setLoginOpen(true)} />

      <BottomNav
        cartCount={cartCount}
        onCartClick={() => setCheckoutOpen(true)}
        onAccountClick={() => setLoginOpen(true)}
      />

      {/* Interactive Product Detail Modal */}
      {selectedProduct ? (
        <ProductDetailsModal
          product={selectedProduct}
          allProducts={allProductsList}
          storeName={storeName}
          onSelectProduct={(p) => {
            setSelectedProduct(p);
            setModalQty(1);
          }}
          onClose={() => setSelectedProduct(null)}
          onAddToCart={(qty) => {
            handleAddProductToCart(selectedProduct, qty);
            setSelectedProduct(null);
          }}
          onBuyNow={(qty) => {
            handleAddProductToCart(selectedProduct, qty);
            setSelectedProduct(null);
            setCheckoutOpen(true);
          }}
        />
      ) : null}

      <LoginModal
        open={loginOpen}
        onClose={() => setLoginOpen(false)}
        onLogin={handleLogin}
        storeName={storeName}
        logoSrc={storeLogoSrc}
      />

      <CheckoutModal
        open={checkoutOpen}
        onClose={() => setCheckoutOpen(false)}
        storeName={storeName}
        logoSrc={storeLogoSrc}
        cartItems={cartItems}
        onUpdateQty={(id, delta) => {
          setCartItems((prev) =>
            prev
              .map((item) =>
                item.id === id ? { ...item, qty: Math.max(1, (item.qty || 1) + delta) } : item
              )
          );
        }}
        onRemoveItem={(id) => {
          setCartItems((prev) => prev.filter((item) => item.id !== id));
        }}
        onOrderPlaced={() => setCartItems([])}
      />
    </div>
  );
}

