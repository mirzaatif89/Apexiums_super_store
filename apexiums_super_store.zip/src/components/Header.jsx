import React from 'react';
import { Heart, Search, ShoppingCart, User2 } from 'lucide-react';

export default function Header({
  storeName = 'Apexiums Super Store',
  logoSrc,
  authUser,
  cartCount = 0,
  onAccountClick,
  onCartClick,
  onMenuToggle,
  mobileMenuOpen,
  searchQuery,
  onSearchChange,
  onSearchSubmit,
  onSearchFocus
}) {
  const searchTags = ['Bluetooth Earbuds', 'Smart Watch', 'PS5 Controller', 'Oversized Tee', 'Backpack'];

  return (
    <header className="sticky top-0 z-40 bg-white/98 backdrop-blur-md shadow-xs border-b border-slate-100">
      {/* Primary Brand Header Bar */}
      <div className="bg-white py-2 sm:py-3">
        <div className="mx-auto max-w-7xl px-3 sm:px-4 lg:px-6">
          <div className="flex items-center justify-between gap-2 sm:gap-4 lg:gap-6">
            {/* Logo */}
            <a href="#" className="flex h-10 sm:h-11 items-center shrink group min-w-0">
              <div className="bg-white p-0.5 rounded-xl flex items-center justify-center transition-transform group-hover:scale-[1.02]">
                <img
                  src={logoSrc}
                  alt={storeName}
                  loading="lazy"
                  className="h-8 sm:h-10 w-auto max-w-[7.5rem] xs:max-w-[9rem] sm:max-w-[12rem] object-contain"
                />
              </div>
            </a>

            {/* Search Bar - Desktop */}
            <div className="hidden flex-1 max-w-2xl lg:block">
              <form onSubmit={onSearchSubmit} className="relative">
                <div className="flex h-11 w-full items-center rounded-full bg-slate-50/80 border border-slate-200 p-1 shadow-2xs focus-within:bg-white focus-within:border-emerald-600 focus-within:ring-4 focus-within:ring-emerald-100/60 transition-all duration-200">
                  <input
                    value={searchQuery}
                    onChange={(event) => onSearchChange(event.target.value)}
                    onFocus={onSearchFocus}
                    className="min-w-0 flex-1 bg-transparent px-4 text-sm font-medium text-slate-800 outline-none placeholder:text-slate-400"
                    placeholder="Search products, brands, and categories..."
                    aria-label="Search products"
                  />
                  <button
                    type="submit"
                    className="inline-flex h-9 items-center gap-1.5 px-5 rounded-full bg-emerald-600 font-semibold text-xs uppercase tracking-wider text-white shadow-2xs transition-all hover:bg-emerald-700 active:scale-95 cursor-pointer shrink-0"
                    aria-label="Search"
                  >
                    <Search size={16} className="text-white" />
                    <span>Search</span>
                  </button>
                </div>
              </form>
              {/* Quick Search Tag Pills */}
              <div className="mt-1.5 flex items-center gap-2 text-[11px] text-slate-500 px-3">
                <span className="font-bold text-slate-600">Trending:</span>
                {searchTags.map((tag) => (
                  <button
                    key={tag}
                    type="button"
                    onClick={() => onSearchChange(tag)}
                    className="font-medium hover:text-emerald-600 transition-colors cursor-pointer"
                  >
                    {tag}
                  </button>
                ))}
              </div>
            </div>

            {/* Action Buttons: Wishlist, User Account & Cart */}
            <div className="flex items-center gap-1.5 sm:gap-2.5 shrink-0">
              <button
                type="button"
                className="group relative inline-flex h-10 w-10 sm:h-11 sm:w-11 shrink-0 items-center justify-center rounded-xl border border-slate-200 bg-slate-50/80 text-slate-700 shadow-2xs transition-all hover:bg-emerald-50 hover:border-emerald-200 hover:text-emerald-700 active:scale-95 cursor-pointer"
                aria-label="Wishlist"
                title="Wishlist"
              >
                <Heart className="h-5 w-5 text-slate-600 transition-transform group-hover:scale-110 group-hover:text-emerald-600" />
              </button>

              <button
                type="button"
                onClick={onAccountClick}
                className="group relative inline-flex h-10 w-10 sm:h-11 sm:w-11 shrink-0 items-center justify-center rounded-xl border border-slate-200 bg-slate-50/80 text-slate-700 shadow-2xs transition-all hover:bg-emerald-50 hover:border-emerald-200 hover:text-emerald-700 active:scale-95 cursor-pointer"
                aria-label={authUser?.name ? authUser.name : 'Sign In / Register'}
                title={authUser?.name ? authUser.name : 'Sign In / Register'}
              >
                <User2 className="h-5 w-5 text-slate-600 transition-transform group-hover:scale-110 group-hover:text-emerald-600" />
              </button>

              <button
                type="button"
                onClick={onCartClick}
                className={`group relative inline-flex h-10 w-10 sm:h-11 sm:w-11 shrink-0 items-center justify-center rounded-xl border shadow-2xs transition-all active:scale-95 cursor-pointer ${
                  cartCount > 0
                    ? 'border-emerald-200 bg-emerald-50/90 text-emerald-800 hover:bg-emerald-100 hover:border-emerald-300'
                    : 'border-slate-200 bg-slate-50/80 text-slate-700 hover:bg-emerald-50 hover:border-emerald-200 hover:text-emerald-700'
                }`}
                aria-label="Cart"
                title="Cart"
              >
                <ShoppingCart className={`h-5 w-5 transition-transform group-hover:scale-110 ${cartCount > 0 ? 'text-emerald-600' : 'text-slate-600 group-hover:text-emerald-600'}`} />
                {cartCount > 0 ? (
                  <span className="absolute -top-1.5 -right-1.5 flex h-5 min-w-5 items-center justify-center rounded-full bg-emerald-600 px-1 text-[10px] font-extrabold text-white ring-2 ring-white shadow-2xs animate-in zoom-in-75">
                    {cartCount}
                  </span>
                ) : null}
              </button>
            </div>
          </div>

          {/* Search Bar - Mobile */}
          <form onSubmit={onSearchSubmit} className="mt-2.5 lg:hidden">
            <div className="flex h-10 sm:h-11 w-full items-center rounded-full bg-slate-50/80 border border-slate-200 p-1 shadow-2xs focus-within:bg-white focus-within:border-emerald-600 focus-within:ring-2 focus-within:ring-emerald-100 transition-all">
              <input
                value={searchQuery}
                onChange={(event) => onSearchChange(event.target.value)}
                onFocus={onSearchFocus}
                className="min-w-0 flex-1 bg-transparent px-3.5 sm:px-4 text-xs sm:text-sm font-medium text-slate-800 outline-none placeholder:text-slate-400"
                placeholder="Search products in Apexiums Super Store..."
                aria-label="Search products"
              />
              <button
                type="submit"
                className="inline-flex h-8 w-8 sm:h-9 sm:w-9 items-center justify-center rounded-full bg-emerald-600 text-white cursor-pointer transition-colors hover:bg-emerald-700 active:scale-95 shrink-0"
                aria-label="Search"
              >
                <Search size={16} className="text-white sm:hidden" />
                <Search size={18} className="text-white hidden sm:block" />
              </button>
            </div>
          </form>
        </div>
      </div>
    </header>
  );
}



