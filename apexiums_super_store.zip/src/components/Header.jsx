import React from 'react';
import { Heart, Search, Shield, ShoppingCart, User } from 'lucide-react';

export default function Header({
  storeName = 'Apexiums Super Store',
  logoSrc,
  authUser,
  cartCount = 0,
  onAccountClick,
  onAdminClick,
  onCartClick,
  onWishlistClick,
  searchQuery,
  onSearchChange,
  onSearchSubmit,
  onSearchFocus
}) {
  return (
    <header className="w-full transition-all">
      {/* Red Container with 40px Rounded Bottom Corners */}
      <div className="bg-[#E8262A] text-white shadow-lg rounded-b-[40px] sm:rounded-b-[52px] px-5 sm:px-8 pt-9 pb-12 sm:pt-12 sm:pb-16">
        <div className="mx-auto max-w-2xl sm:max-w-3xl w-full space-y-6 sm:space-y-7">
          {/* Top Row: Account / Login Register & Admin Portal Button */}
          <div className="flex items-center justify-between gap-3 w-full">
            <div className="flex items-center gap-2.5 flex-wrap">
              <button
                type="button"
                onClick={onAccountClick}
                className="flex items-center gap-2.5 h-11 sm:h-12 px-4 rounded-2xl bg-white/15 hover:bg-white/25 text-white backdrop-blur-md transition active:scale-95 cursor-pointer text-xs sm:text-sm font-bold border border-white/20 shadow-xs"
                title={authUser?.name || "Login / Register"}
                aria-label="Login / Register"
              >
                <div className="flex h-7.5 w-7.5 items-center justify-center rounded-xl bg-white text-[#E8262A] shadow-xs">
                  <User className="h-4 w-4" />
                </div>
                <span className="truncate max-w-[120px] sm:max-w-[200px]">
                  {authUser?.name ? authUser.name : "Login / Register"}
                </span>
              </button>

              <button
                type="button"
                onClick={onAdminClick || onAccountClick}
                className="flex items-center gap-2 h-11 sm:h-12 px-4 rounded-2xl bg-black/30 hover:bg-black/50 text-white backdrop-blur-md transition active:scale-95 cursor-pointer text-xs sm:text-sm font-black border border-amber-400/40 shadow-xs text-amber-200"
                title="Open Admin Dashboard"
                aria-label="Admin Portal"
              >
                <Shield className="h-4 w-4 text-amber-300" />
                <span>Admin Portal</span>
              </button>
            </div>

            {/* Right: Shopping Cart Button */}
            <button
              type="button"
              onClick={onCartClick}
              className="group relative flex h-11 w-11 sm:h-12 sm:w-12 items-center justify-center rounded-2xl bg-white/20 hover:bg-white/30 text-white backdrop-blur-md border border-white/20 shadow-xs transition active:scale-95 cursor-pointer shrink-0"
              aria-label="Cart"
              title="Cart"
            >
              <ShoppingCart className="h-5 w-5 text-white transition-transform group-hover:scale-110" />
              {cartCount > 0 ? (
                <span className="absolute -top-1.5 -right-1.5 flex h-5 min-w-5 items-center justify-center rounded-full bg-white px-1 text-[10px] font-black text-[#E8262A] shadow-md ring-2 ring-[#E8262A] animate-bounce">
                  {cartCount}
                </span>
              ) : null}
            </button>
          </div>

          {/* Search Row: Search Input + Wishlist (Heart) Button */}
          <div className="flex items-center gap-2.5 w-full">
            <form onSubmit={onSearchSubmit} className="flex-1 flex items-center">
              <div className="relative flex-1 flex h-12 sm:h-13 items-center rounded-2xl bg-white px-4 shadow-sm focus-within:ring-2 focus-within:ring-red-300 transition-all">
                <Search
                  size={19}
                  className="text-slate-400 shrink-0 mr-3"
                />
                <input
                  value={searchQuery}
                  onChange={(event) => onSearchChange(event.target.value)}
                  onFocus={onSearchFocus}
                  className="w-full bg-transparent text-sm font-medium text-slate-800 outline-none placeholder:text-slate-400"
                  placeholder="Search products, brands, categories..."
                  aria-label="Search"
                />
              </div>
            </form>

            {/* Wishlist Button next to Search Bar */}
            <button
              type="button"
              onClick={onWishlistClick}
              className="flex h-12 w-12 sm:h-13 sm:w-13 shrink-0 items-center justify-center rounded-2xl bg-white text-[#E8262A] shadow-sm transition hover:bg-slate-50 hover:scale-105 active:scale-95 cursor-pointer"
              title="Wishlist"
              aria-label="Wishlist"
            >
              <Heart size={20} className="text-[#E8262A]" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}




