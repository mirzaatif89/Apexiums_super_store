import React from 'react';
import { Heart, Menu, Search, ShoppingCart, User } from 'lucide-react';

export default function Header({
  storeName = 'Apexiums',
  logoSrc,
  authUser,
  cartCount = 0,
  wishlistCount = 0,
  onAccountClick,
  onCartClick,
  onWishlistClick,
  onMenuToggle,
  onMenuClick,
  searchQuery,
  onSearchChange,
  onSearchSubmit,
  onSearchFocus
}) {
  return (
    <header className="w-full bg-[#E8262A] text-white transition-all relative z-20 shadow-md">
      {/* Header Content Container - Full Available Width */}
      <div className="w-full max-w-none px-4 sm:px-6 lg:px-8 py-3 sm:py-3.5 md:py-2.5">
        
        {/* DESKTOP LAYOUT (md & larger): Menu on left, search in center, cart, wishlist & account on right */}
        <div className="hidden md:flex items-center justify-between gap-6 w-full">
          {/* Left: Menu */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={onMenuToggle || onMenuClick}
              className="flex h-10 w-10 lg:h-11 lg:w-11 items-center justify-center rounded-[16px] bg-white/20 hover:bg-white/30 text-white transition active:scale-95 cursor-pointer backdrop-blur-md"
              aria-label="Menu"
              title="Menu"
            >
              <Menu size={21} strokeWidth={2.2} className="text-white" />
            </button>
          </div>

          {/* Center: Search Bar */}
          <form onSubmit={onSearchSubmit} className="flex-1 max-w-2xl mx-auto">
            <div className="relative flex h-10 lg:h-11 items-center rounded-full bg-white px-4 shadow-sm focus-within:ring-2 focus-within:ring-white/40 transition-all">
              <Search size={18} className="text-slate-400 shrink-0 mr-2.5" />
              <input
                value={searchQuery}
                onChange={(event) => onSearchChange(event.target.value)}
                onFocus={onSearchFocus}
                className="w-full bg-transparent text-sm font-medium text-slate-900 outline-none placeholder:text-slate-400"
                placeholder="Search products, categories..."
                aria-label="Search"
              />
            </div>
          </form>

          {/* Right: Wishlist, Cart & Account Icons */}
          <div className="flex items-center gap-2.5 shrink-0">
            <button
              type="button"
              onClick={onWishlistClick}
              className="group relative flex h-10 w-10 lg:h-11 lg:w-11 items-center justify-center rounded-[16px] bg-white/20 hover:bg-white/30 text-white shadow-xs transition active:scale-95 cursor-pointer backdrop-blur-md"
              title="Wishlist"
              aria-label="Wishlist"
            >
              <Heart size={20} className="text-white transition-transform group-hover:scale-110" />
              {wishlistCount > 0 ? (
                <span className="absolute -top-1 -right-1 flex h-4.5 min-w-4.5 items-center justify-center rounded-full bg-white px-1 text-[9px] font-black text-[#E8262A] shadow-md animate-bounce">
                  {wishlistCount}
                </span>
              ) : null}
            </button>

            <button
              type="button"
              onClick={onCartClick}
              className="group relative flex h-10 w-10 lg:h-11 lg:w-11 items-center justify-center rounded-[16px] bg-white/20 hover:bg-white/30 text-white shadow-xs transition active:scale-95 cursor-pointer backdrop-blur-md"
              title="Cart"
              aria-label="Cart"
            >
              <ShoppingCart size={20} strokeWidth={2.2} className="text-white transition-transform group-hover:scale-105" />
              {cartCount > 0 ? (
                <span className="absolute -top-1 -right-1 flex h-4.5 min-w-4.5 items-center justify-center rounded-full bg-white px-1 text-[9px] font-black text-[#E8262A] shadow-md animate-bounce">
                  {cartCount}
                </span>
              ) : null}
            </button>

            {onAccountClick ? (
              <button
                type="button"
                onClick={onAccountClick}
                className="group relative flex h-10 w-10 lg:h-11 lg:w-11 items-center justify-center rounded-[16px] bg-white/20 hover:bg-white/30 text-white shadow-xs transition active:scale-95 cursor-pointer backdrop-blur-md"
                title="Account"
                aria-label="Account"
              >
                <User size={20} className="text-white transition-transform group-hover:scale-105" />
              </button>
            ) : null}
          </div>
        </div>

        {/* MOBILE LAYOUT (under md): Unchanged 2-row layout */}
        <div className="block md:hidden space-y-3 sm:space-y-3.5">
          {/* Top Row: Menu on Left, Cart on Far Right */}
          <div className="flex items-center justify-between gap-3 w-full">
            <button
              type="button"
              onClick={onMenuToggle || onMenuClick}
              className="flex h-10 w-10 sm:h-11 sm:w-11 items-center justify-center rounded-[16px] bg-white/20 hover:bg-white/30 text-white transition active:scale-95 cursor-pointer shrink-0 backdrop-blur-md"
              aria-label="Menu"
              title="Menu"
            >
              <Menu size={20} strokeWidth={2.2} className="text-white" />
            </button>

            <button
              type="button"
              onClick={onCartClick}
              className="group relative flex h-10 w-10 sm:h-11 sm:w-11 items-center justify-center rounded-[16px] bg-white/20 hover:bg-white/30 text-white transition active:scale-95 cursor-pointer shrink-0 backdrop-blur-md"
              title="Cart"
              aria-label="Cart"
            >
              <ShoppingCart size={20} strokeWidth={2.2} className="text-white transition-transform group-hover:scale-105" />
              {cartCount > 0 ? (
                <span className="absolute -top-1 -right-1 flex h-4.5 min-w-4.5 items-center justify-center rounded-full bg-white px-1 text-[9px] font-black text-[#E8262A] shadow-md animate-bounce">
                  {cartCount}
                </span>
              ) : null}
            </button>
          </div>

          {/* Second Row: Search Input Row + Wishlist Button */}
          <div className="flex items-center gap-2.5 sm:gap-3 w-full">
            <form onSubmit={onSearchSubmit} className="flex-1 flex items-center min-w-0">
              <div className="relative flex-1 flex h-10 sm:h-11 items-center rounded-full bg-white px-4 shadow-sm focus-within:ring-2 focus-within:ring-white/40 transition-all">
                <Search
                  size={18}
                  className="text-slate-400 shrink-0 mr-2.5"
                />
                <input
                  value={searchQuery}
                  onChange={(event) => onSearchChange(event.target.value)}
                  onFocus={onSearchFocus}
                  className="w-full bg-transparent text-xs sm:text-sm font-medium text-slate-900 outline-none placeholder:text-slate-400"
                  placeholder="Search"
                  aria-label="Search"
                />
              </div>
            </form>

            <button
              type="button"
              onClick={onWishlistClick}
              className="group relative flex h-10 w-10 sm:h-11 sm:w-11 shrink-0 items-center justify-center rounded-2xl bg-white/20 hover:bg-white/30 text-white shadow-xs transition active:scale-95 cursor-pointer backdrop-blur-xs"
              title="Wishlist"
              aria-label="Wishlist"
            >
              <Heart size={19} className="text-white transition-transform group-hover:scale-110" />
              {wishlistCount > 0 ? (
                <span className="absolute -top-1 -right-1 flex h-4.5 min-w-4.5 items-center justify-center rounded-full bg-white px-1 text-[9px] font-black text-[#E8262A] shadow-md animate-bounce">
                  {wishlistCount}
                </span>
              ) : null}
            </button>
          </div>
        </div>

      </div>
    </header>
  );
}







