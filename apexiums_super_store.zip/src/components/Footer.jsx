import React from 'react';

export default function Footer({ sections, paymentMethods, storeName, logoSrc }) {
  return (
    <footer className="w-full mt-4 sm:mt-6 border-t border-emerald-100 bg-white text-slate-700 pb-16">
      {/* Main Footer Links */}
      <div className="mx-auto max-w-7xl px-3 py-6 sm:py-8 sm:px-4 lg:px-6">
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-5">
          {/* Brand Info & App Download */}
          <div className="space-y-4 lg:col-span-2">
            <div className="flex items-center gap-2">
              <div className="bg-white p-1 rounded-xl border border-slate-200">
                <img src={logoSrc} alt={storeName} loading="lazy" className="h-10 w-auto object-contain" />
              </div>
              <span className="text-lg font-black text-slate-900">{storeName}</span>
            </div>
            <p className="text-xs text-slate-500 leading-relaxed max-w-sm">
              Pakistan's leading online store for electronics, fashion, home essentials & lifestyle products with fast delivery and authentic items.
            </p>

            <div className="pt-2">
              <p className="text-xs font-bold uppercase tracking-wider text-slate-900 mb-2">Payment Methods</p>
              <div className="flex flex-wrap gap-1.5">
                {paymentMethods.map((method) => (
                  <span
                    key={method}
                    className="inline-flex items-center rounded-md border border-slate-200 bg-slate-50 px-2.5 py-1 text-[11px] font-semibold text-slate-700"
                  >
                    {method}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Dynamic Footer Sections */}
          {sections.map((section) => (
            <div key={section.title} className="space-y-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900">{section.title}</h3>
              <ul className="space-y-2">
                {section.links.map((link) => (
                  <li key={link}>
                    <a href="#" className="text-xs text-slate-600 transition hover:text-emerald-700 hover:underline">
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom Bar */}
        <div className="mt-10 border-t border-slate-100 pt-6 flex flex-wrap items-center justify-between gap-4 text-xs text-slate-500">
          <p>© {new Date().getFullYear()} {storeName}. All rights reserved.</p>
          <div className="flex items-center gap-4">
            <a href="#" className="hover:text-emerald-700">Privacy Policy</a>
            <span>•</span>
            <a href="#" className="hover:text-emerald-700">Terms of Use</a>
            <span>•</span>
            <a href="#" className="hover:text-emerald-700">Vendor Center</a>
          </div>
        </div>
      </div>
    </footer>
  );
}

