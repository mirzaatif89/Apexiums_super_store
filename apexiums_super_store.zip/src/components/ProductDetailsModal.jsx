import React, { useState, useMemo, useEffect } from 'react';
import {
  ArrowLeft,
  Search,
  Share2,
  Heart,
  MoreVertical,
  Star,
  Truck,
  ShieldCheck,
  RotateCcw,
  MapPin,
  CheckCircle2,
  MessageCircle,
  ShoppingCart,
  ShoppingBag,
  Plus,
  Minus,
  X,
  Check,
  Sparkles,
  PackageCheck,
  Award
} from 'lucide-react';

export default function ProductDetailsModal({
  product,
  allProducts = [],
  onClose,
  onAddToCart,
  onBuyNow,
  onSelectProduct,
  storeName = 'Apexiums Super Store'
}) {
  if (!product) return null;

  const [quantity, setQuantity] = useState(1);
  const [selectedImgIndex, setSelectedImgIndex] = useState(0);
  const [isWishlist, setIsWishlist] = useState(false);
  const [sharedToast, setSharedToast] = useState(false);
  const [selectedColor, setSelectedColor] = useState('Standard Black');
  const [selectedSize, setSelectedSize] = useState('Standard');
  const [searchQuery, setSearchQuery] = useState('');

  // Reset internal state when selected product changes
  useEffect(() => {
    setSelectedImgIndex(0);
    setQuantity(1);
    setSelectedColor('Standard Black');
    setSelectedSize('Standard');
  }, [product?.id]);

  // Derive Brand name dynamically if not supplied
  const brandName = useMemo(() => {
    if (product.brand && product.brand !== 'Apexiums Tech') return product.brand;
    return '';
  }, [product]);

  // Gallery images setup (fallback angles if array not provided)
  const galleryImages = useMemo(() => {
    if (Array.isArray(product.gallery) && product.gallery.length > 0) {
      return product.gallery;
    }
    // Generate 4 image slots using product image
    return [
      product.image,
      product.image,
      product.image,
      product.image
    ];
  }, [product]);

  // Discount percentage
  const discountPercent = useMemo(() => {
    if (product.originalPrice && product.originalPrice > product.price) {
      return Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100);
    }
    return 20;
  }, [product]);

  // Color options
  const colorOptions = useMemo(() => {
    const cat = (product.category || '').toLowerCase();
    if (cat.includes('fashion') || cat.includes('apparel')) {
      return ['Matte Black', 'Emerald Green', 'Navy Blue', 'Off-White'];
    }
    if (cat.includes('electronics') || cat.includes('gaming') || cat.includes('audio')) {
      return ['Midnight Black', 'Space Gray', 'Silver Gold', 'Cyber Blue'];
    }
    return ['Standard Black', 'Pure White', 'Metallic Silver'];
  }, [product]);

  // Size/Variant options
  const variantOptions = useMemo(() => {
    const cat = (product.category || '').toLowerCase();
    if (cat.includes('fashion')) {
      return ['S', 'M', 'L', 'XL'];
    }
    if (cat.includes('electronics') || cat.includes('audio')) {
      return ['Standard', 'Pro Max Edition'];
    }
    return ['Standard Unit', 'Combo Pack'];
  }, [product]);

  // Dynamically constructed Product Details List
  const productDetails = useMemo(() => {
    const details = [];
    if (brandName) details.push({ label: 'Brand', value: brandName });
    if (product.category) details.push({ label: 'Category', value: product.category });
    if (product.material) details.push({ label: 'Material', value: product.material });
    if (selectedColor || product.color) details.push({ label: 'Color', value: selectedColor || product.color });
    if (selectedSize || product.size) details.push({ label: 'Size', value: selectedSize || product.size });
    if (product.weight) details.push({ label: 'Weight', value: product.weight });
    if (product.packageContents) {
      details.push({ label: 'Package Contents', value: product.packageContents });
    } else {
      details.push({ label: 'Package Contents', value: `1x ${product.title}` });
    }
    if (product.warranty) {
      details.push({ label: 'Warranty', value: product.warranty });
    } else {
      details.push({ label: 'Warranty', value: '1 Year Official Warranty' });
    }
    details.push({ label: 'Condition', value: '100% Brand New & Authentic' });
    return details;
  }, [product, brandName, selectedColor, selectedSize]);

  // Key Features
  const keyFeatures = useMemo(() => {
    if (Array.isArray(product.features) && product.features.length > 0) {
      return product.features;
    }
    return [
      'Certified Authentic & Quality Tested',
      'Fast Nationwide Express Delivery',
      'Cash on Delivery Available',
      '100% Satisfaction Guarantee'
    ];
  }, [product]);

  // Product Description Fallback
  const productDescription = useMemo(() => {
    if (product.description && product.description.trim().length > 10) {
      return product.description;
    }
    return `The ${product.title} is an authentic, high-performance product engineered for exceptional quality, durability, and customer satisfaction. Sourced directly from certified suppliers and inspected for peak quality by ${storeName}. Perfect for everyday usage with high reliability and full seller warranty support.`;
  }, [product, storeName]);

  // Filter Related Products from same category
  const relatedProducts = useMemo(() => {
    if (!allProducts || allProducts.length === 0) return [];
    const sameCat = allProducts.filter(
      (p) => p.id !== product.id && p.category === product.category
    );
    if (sameCat.length >= 3) return sameCat.slice(0, 4);
    // Fallback to other products if category has few items
    const others = allProducts.filter((p) => p.id !== product.id);
    return others.slice(0, 4);
  }, [product, allProducts]);

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: product.title,
        text: `Check out ${product.title} on ${storeName}!`,
        url: window.location.href
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(window.location.href);
      setSharedToast(true);
      setTimeout(() => setSharedToast(false), 2500);
    }
  };

  const handleWhatsAppOrder = () => {
    const message = encodeURIComponent(
      `Hello ${storeName}! I am interested in purchasing:\n\n*Product:* ${product.title}\n*Price:* Rs ${product.price.toLocaleString('en-PK')}\n*Selected Color:* ${selectedColor}\n*Variant:* ${selectedSize}\n*Quantity:* ${quantity}\n\nPlease assist me with placing this order.`
    );
    window.open(`https://wa.me/923000000000?text=${message}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-[90] flex items-start sm:items-center justify-center bg-slate-950/70 backdrop-blur-xs p-0 sm:pt-2 sm:pb-4 sm:px-4 overflow-y-auto font-sans">
      {/* Backdrop overlay */}
      <div className="fixed inset-0" onClick={onClose} aria-hidden="true" />

      {/* Main Modal Container */}
      <div className="relative z-10 w-full max-w-4xl min-h-screen sm:min-h-0 overflow-hidden sm:rounded-[20px] bg-slate-50 shadow-2xl flex flex-col my-0 sm:my-auto border border-slate-200/80">
        
        {/* 1. STICKY TOP NAVIGATION BAR */}
        <header className="sticky top-0 z-30 flex items-center justify-between gap-2 border-b border-slate-200/80 bg-white/95 backdrop-blur-md px-3 sm:px-5 py-2 shadow-xs">
          {/* Back Button */}
          <button
            type="button"
            onClick={onClose}
            className="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-slate-100 text-slate-700 transition hover:bg-slate-200 active:scale-95 cursor-pointer"
            aria-label="Go back"
          >
            <ArrowLeft size={18} />
          </button>

          {/* Clean Title Center (Search bar & Search icon removed) */}
          <div className="flex-1 text-center font-extrabold text-xs sm:text-sm text-slate-800 truncate px-2">
            Product View
          </div>

          {/* Action Buttons Right */}
          <div className="flex items-center gap-1 sm:gap-2 shrink-0">
            {/* Share */}
            <button
              type="button"
              onClick={handleShare}
              className="inline-flex h-9 w-9 items-center justify-center rounded-full bg-slate-100 text-slate-700 hover:bg-slate-200 transition active:scale-95 cursor-pointer"
              title="Share Product"
            >
              <Share2 size={16} />
            </button>

            {/* Wishlist */}
            <button
              type="button"
              onClick={() => setIsWishlist(!isWishlist)}
              className={`inline-flex h-9 w-9 items-center justify-center rounded-full transition active:scale-95 cursor-pointer ${
                isWishlist
                  ? 'bg-rose-50 text-rose-600'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
              title="Add to Wishlist"
            >
              <Heart size={16} fill={isWishlist ? 'currentColor' : 'none'} />
            </button>

            {/* Close Modal Button */}
            <button
              type="button"
              onClick={onClose}
              className="inline-flex h-9 w-9 items-center justify-center rounded-full bg-slate-100 text-slate-700 hover:bg-slate-200 transition active:scale-95 cursor-pointer"
              title="Close"
            >
              <X size={18} />
            </button>
          </div>
        </header>

        {/* Copy Share Toast Notification */}
        {sharedToast && (
          <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 rounded-full bg-slate-900 px-4 py-2 text-xs font-medium text-white shadow-lg">
            Link copied to clipboard!
          </div>
        )}

        {/* Scrollable Body Container */}
        <div className="flex-1 overflow-y-auto max-h-[calc(100vh-130px)] p-3 sm:p-6 space-y-5">
          
          {/* Main Top Product Card Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 bg-white p-4 sm:p-6 rounded-[20px] border border-slate-100 shadow-xs">
            
            {/* 2. PRODUCT IMAGE GALLERY */}
            <div className="space-y-3">
              {/* Main Image View */}
              <div className="relative overflow-hidden rounded-[18px] bg-slate-50 border border-slate-100 group aspect-square flex items-center justify-center">
                <img
                  src={galleryImages[selectedImgIndex]}
                  alt={product.title}
                  className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                />

                {/* Discount Badge Top Left */}
                {product.badge && (
                  <span className="absolute top-3 left-3 rounded-lg bg-[#E8262A] px-2.5 py-1 text-[11px] font-black uppercase text-white shadow-sm tracking-wider">
                    {product.badge}
                  </span>
                )}

                {/* Small Image Counter Bottom Right */}
                <div className="absolute bottom-3 right-3 rounded-full bg-slate-900/75 backdrop-blur-xs px-2.5 py-0.5 text-[11px] font-bold text-white shadow-sm">
                  {selectedImgIndex + 1} / {galleryImages.length}
                </div>
              </div>

              {/* Thumbnails Row */}
              <div className="flex items-center gap-2 overflow-x-auto pb-1">
                {galleryImages.map((img, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setSelectedImgIndex(idx)}
                    className={`relative h-16 w-16 shrink-0 overflow-hidden rounded-xl border-2 transition cursor-pointer ${
                      selectedImgIndex === idx
                        ? 'border-[#E8262A] ring-2 ring-red-500/20'
                        : 'border-slate-200 opacity-70 hover:opacity-100'
                    }`}
                  >
                    <img src={img} alt="" className="h-full w-full object-cover" />
                  </button>
                ))}
              </div>
            </div>

            {/* 3. PRODUCT INFORMATION */}
            <div className="flex flex-col justify-between space-y-4">
              <div>
                {/* Brand & Stock Status Bar */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {brandName ? (
                      <>
                        <span className="text-[11px] font-extrabold uppercase tracking-wider text-red-800 bg-red-50 px-2.5 py-1 rounded-md border border-red-200/60">
                          {brandName}
                        </span>
                        <span className="text-[11px] text-slate-400">•</span>
                      </>
                    ) : null}
                    <span className="text-[11px] font-bold text-slate-600 bg-slate-100 px-2.5 py-1 rounded-md">
                      {product.category || 'Product Details'}
                    </span>
                  </div>

                  <span className="inline-flex items-center gap-1.5 text-xs font-bold text-red-600 bg-red-50/80 px-2.5 py-0.5 rounded-full">
                    <span className="h-2 w-2 rounded-full bg-red-500 animate-pulse" />
                    In Stock
                  </span>
                </div>

                {/* Product Name */}
                <h1 className="mt-2.5 text-lg sm:text-xl font-extrabold text-slate-900 leading-snug">
                  {product.title}
                </h1>

                {/* Wishlist & Authenticity Bar */}
                <div className="mt-2 flex items-center justify-between border-b border-slate-100 pb-2.5">
                  <span className="text-xs font-semibold text-red-700">100% Authentic & Certified Quality</span>
                  <button
                    type="button"
                    onClick={() => setIsWishlist(!isWishlist)}
                    className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold transition cursor-pointer ${
                      isWishlist ? 'text-rose-600 bg-rose-50 border border-rose-200' : 'text-slate-500 bg-slate-100 hover:bg-slate-200'
                    }`}
                  >
                    <Heart size={14} fill={isWishlist ? 'currentColor' : 'none'} />
                    <span>{isWishlist ? 'Wishlisted' : 'Add to Wishlist'}</span>
                  </button>
                </div>

                {/* Price Box */}
                <div className="mt-3.5 rounded-2xl bg-red-50/80 p-3.5 border border-red-100">
                  <div className="flex items-baseline gap-2.5 flex-wrap">
                    <span className="text-2xl sm:text-3xl font-black text-[#E8262A]">
                      Rs {product.price.toLocaleString('en-PK')}
                    </span>
                    {product.originalPrice && (
                      <span className="text-sm font-medium text-slate-400 line-through">
                        Rs {product.originalPrice.toLocaleString('en-PK')}
                      </span>
                    )}
                    <span className="rounded-md bg-[#E8262A] px-2 py-0.5 text-[11px] font-extrabold text-white uppercase">
                      {discountPercent}% OFF
                    </span>
                  </div>
                  <p className="mt-1 text-[11px] text-red-800 font-semibold flex items-center gap-1">
                    <CheckCircle2 size={13} className="text-red-600 shrink-0" />
                    Inclusive of all taxes & 7-Day Easy Replacement Warranty
                  </p>
                </div>

                {/* Color Swatches */}
                <div className="mt-3.5 space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-slate-700">Available Color:</span>
                    <span className="font-semibold text-red-700">{selectedColor}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    {colorOptions.map((c) => (
                      <button
                        key={c}
                        type="button"
                        onClick={() => setSelectedColor(c)}
                        className={`px-3 py-1 text-xs rounded-lg border font-semibold transition cursor-pointer ${
                          selectedColor === c
                            ? 'border-[#E8262A] bg-[#E8262A] text-white shadow-xs'
                            : 'border-slate-200 bg-slate-50 text-slate-700 hover:border-slate-300'
                        }`}
                      >
                        {c}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Variant Chips */}
                <div className="mt-3 space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-slate-700">Variant / Size:</span>
                    <span className="font-semibold text-red-700">{selectedSize}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    {variantOptions.map((v) => (
                      <button
                        key={v}
                        type="button"
                        onClick={() => setSelectedSize(v)}
                        className={`px-3 py-1 text-xs rounded-lg border font-semibold transition cursor-pointer ${
                          selectedSize === v
                            ? 'border-[#E8262A] bg-red-50 text-red-700 font-bold border-2'
                            : 'border-slate-200 bg-slate-50 text-slate-700 hover:border-slate-300'
                        }`}
                      >
                        {v}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Quantity Selector */}
              <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                <span className="text-xs font-bold text-slate-700">Quantity</span>
                <div className="flex items-center rounded-xl border border-slate-200 bg-slate-50 p-0.5">
                  <button
                    type="button"
                    onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                    className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-600 hover:bg-white hover:shadow-xs transition cursor-pointer"
                  >
                    <Minus size={14} />
                  </button>
                  <span className="w-10 text-center text-xs font-bold text-slate-900">
                    {quantity}
                  </span>
                  <button
                    type="button"
                    onClick={() => setQuantity((q) => q + 1)}
                    className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-600 hover:bg-white hover:shadow-xs transition cursor-pointer"
                  >
                    <Plus size={14} />
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* 4. PRODUCT DESCRIPTION SECTION */}
          <div className="rounded-[20px] border border-slate-100 bg-white p-4 sm:p-6 shadow-xs space-y-3">
            <h2 className="text-xs font-extrabold uppercase tracking-wider text-slate-800 border-b border-slate-100 pb-2.5">
              Product Description
            </h2>
            <p className="text-xs sm:text-sm text-slate-700 leading-relaxed font-normal">
              {productDescription}
            </p>
          </div>

          {/* 5. PRODUCT DETAILS SECTION */}
          <div className="rounded-[20px] border border-slate-100 bg-white p-4 sm:p-6 shadow-xs space-y-4">
            <h2 className="text-xs font-extrabold uppercase tracking-wider text-slate-800 border-b border-slate-100 pb-2.5">
              Product Details
            </h2>

            {/* Product Specifications & Details Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
              {productDetails.map((detail) => (
                <div key={detail.label} className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                  <span className="font-semibold text-slate-500">{detail.label}</span>
                  <span className="font-bold text-slate-900 text-right">{detail.value}</span>
                </div>
              ))}
            </div>

            {/* Key Features */}
            {keyFeatures.length > 0 && (
              <div className="pt-2 border-t border-slate-100 space-y-2">
                <h3 className="text-xs font-bold text-slate-800">Key Features</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {keyFeatures.map((highlight, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-xs text-slate-700">
                      <CheckCircle2 size={15} className="text-red-600 shrink-0" />
                      <span className="font-medium">{highlight}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* 6. STAR RATING DISPLAY ONLY */}
          <div className="rounded-[20px] border border-slate-100 bg-white p-4 sm:p-5 shadow-xs flex items-center justify-between">
            <div>
              <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-800">Rating</h3>
              <p className="text-[11px] text-slate-500 font-medium">Quality verified product</p>
            </div>
            <div className="flex items-center gap-1.5 bg-amber-50 px-3.5 py-1.5 rounded-xl border border-amber-200/60">
              {[...Array(5)].map((_, i) => (
                <Star key={i} size={16} fill="currentColor" className="text-amber-500" />
              ))}
            </div>
          </div>

          {/* 6. DELIVERY & SHIPPING INFORMATION CARD */}
          <div className="rounded-[20px] border border-slate-100 bg-white p-4 sm:p-5 shadow-xs space-y-3">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
              <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-800 flex items-center gap-2">
                <Truck size={16} className="text-red-600" />
                Delivery & Service Options
              </h3>
              <span className="text-[11px] font-bold text-red-700 bg-red-50 px-2.5 py-0.5 rounded-md">
                Guaranteed Express
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
              {/* Delivery Location */}
              <div className="flex items-start gap-2.5 p-3 rounded-xl bg-slate-50 border border-slate-100">
                <MapPin size={18} className="text-red-600 shrink-0 mt-0.5" />
                <div className="min-w-0">
                  <p className="text-xs font-bold text-slate-800">Deliver To</p>
                  <p className="text-[11px] text-slate-500 truncate">Lahore, Punjab, Pakistan</p>
                  <span className="text-[10px] font-bold text-red-700 cursor-pointer hover:underline">
                    Change Location
                  </span>
                </div>
              </div>

              {/* Delivery Time & Cost */}
              <div className="flex items-start gap-2.5 p-3 rounded-xl bg-slate-50 border border-slate-100">
                <Truck size={18} className="text-red-600 shrink-0 mt-0.5" />
                <div className="min-w-0">
                  <p className="text-xs font-bold text-slate-800">Standard Delivery</p>
                  <p className="text-[11px] text-slate-500">2 to 4 Days</p>
                  <p className="text-[10px] font-bold text-red-700">Rs 99 (FREE over Rs 1,000)</p>
                </div>
              </div>

              {/* Guarantees & Returns */}
              <div className="flex items-start gap-2.5 p-3 rounded-xl bg-slate-50 border border-slate-100">
                <ShieldCheck size={18} className="text-red-600 shrink-0 mt-0.5" />
                <div className="min-w-0">
                  <p className="text-xs font-bold text-slate-800">Buyer Protection</p>
                  <p className="text-[11px] text-slate-500">Cash on Delivery & 7-Day Easy Return</p>
                </div>
              </div>
            </div>
          </div>

          {/* 8. RELATED PRODUCTS SECTION */}
          {relatedProducts.length > 0 && (
            <div className="rounded-[20px] border border-slate-100 bg-white p-4 sm:p-5 shadow-xs space-y-3">
              <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
                <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-900">
                  Related Products
                </h3>
                <span className="text-xs font-semibold text-red-700">From {product.category}</span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {relatedProducts.map((rel) => (
                  <div
                    key={rel.id}
                    onClick={() => onSelectProduct && onSelectProduct(rel)}
                    className="group flex flex-col justify-between p-2.5 rounded-xl border border-slate-100 bg-slate-50/50 hover:bg-white hover:border-red-300 hover:shadow-md transition cursor-pointer"
                  >
                    <div className="space-y-2">
                      <div className="aspect-square rounded-lg overflow-hidden bg-white">
                        <img
                          src={rel.image}
                          alt={rel.title}
                          className="h-full w-full object-cover group-hover:scale-105 transition duration-300"
                        />
                      </div>
                      <p className="text-xs font-bold text-slate-800 line-clamp-2 group-hover:text-red-700">
                        {rel.title}
                      </p>
                    </div>
                    <div className="mt-2 pt-1 border-t border-slate-100 flex items-center justify-between">
                      <span className="text-xs font-extrabold text-[#E8262A]">
                        Rs {rel.price.toLocaleString('en-PK')}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>

        {/* 9. STICKY BOTTOM ACTION BAR */}
        <footer className="sticky bottom-0 z-30 border-t border-slate-200 bg-white/95 backdrop-blur-md p-3 sm:px-6 shadow-2xl">
          <div className="flex items-center justify-between gap-2 sm:gap-3 max-w-4xl mx-auto">
            {/* WhatsApp Direct Order Button */}
            <button
              type="button"
              onClick={handleWhatsAppOrder}
              className="inline-flex min-h-12 items-center justify-center gap-1.5 px-3 sm:px-4 rounded-xl bg-emerald-600 text-white font-bold text-xs uppercase tracking-wider shadow-md transition hover:bg-emerald-700 active:scale-95 shrink-0 cursor-pointer"
              title="Order via WhatsApp"
            >
              <MessageCircle size={18} />
              <span className="hidden xs:inline">WhatsApp</span>
            </button>

            {/* Add To Cart Button */}
            <button
              type="button"
              onClick={() => onAddToCart(quantity)}
              className="flex-1 inline-flex min-h-12 items-center justify-center gap-2 rounded-xl border-2 border-[#E8262A] bg-red-50 text-red-800 font-extrabold text-xs uppercase tracking-wider transition hover:bg-red-100 active:scale-95 cursor-pointer"
            >
              <ShoppingCart size={17} />
              <span>Add To Cart</span>
            </button>

            {/* Buy Now Button */}
            <button
              type="button"
              onClick={() => onBuyNow(quantity)}
              className="flex-1 inline-flex min-h-12 items-center justify-center gap-2 rounded-xl bg-[#E8262A] text-white font-black text-xs uppercase tracking-wider shadow-md transition hover:bg-red-700 active:scale-95 cursor-pointer"
            >
              <ShoppingBag size={17} />
              <span>Buy Now</span>
            </button>
          </div>
        </footer>

      </div>
    </div>
  );
}
