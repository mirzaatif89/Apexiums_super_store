import React from 'react';
import {
  AlertCircle,
  Building2,
  CheckCircle2,
  CreditCard,
  Download,
  Home,
  MapPin,
  PackageCheck,
  Phone,
  ShieldCheck,
  ShoppingBag,
  ShoppingCart,
  Tag,
  Truck,
  User,
  X
} from 'lucide-react';

export default function CheckoutModal({ open, onClose, storeName, logoSrc, cartItems = [], onOrderPlaced }) {
  const [step, setStep] = React.useState('checkout'); // 'checkout' | 'success'
  const [placedOrderData, setPlacedOrderData] = React.useState(null);

  // Address fields
  const [fullName, setFullName] = React.useState('Muhammad Ali');
  const [phone, setPhone] = React.useState('0300-1234567');
  const [city, setCity] = React.useState('Lahore');
  const [address, setAddress] = React.useState('House #42, Block B, Johar Town');
  const [addressType, setAddressType] = React.useState('Home');

  // Delivery options
  const [deliverySpeed, setDeliverySpeed] = React.useState('standard'); // 'standard'

  // Payment method
  const [paymentMethod, setPaymentMethod] = React.useState('cod'); // 'cod' | 'wallet' | 'card'
  const [cardNumber, setCardNumber] = React.useState('');
  const [cardExpiry, setCardExpiry] = React.useState('');
  const [cardCvc, setCardCvc] = React.useState('');
  const [walletPhone, setWalletPhone] = React.useState('');

  // Coupon code
  const [couponCode, setCouponCode] = React.useState('');
  const [appliedDiscount, setAppliedDiscount] = React.useState(0);
  const [couponMsg, setCouponMsg] = React.useState('');

  // State
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState('');

  const items = cartItems || [];

  const subtotal = items.reduce((sum, item) => sum + (item.price || 0) * (item.qty || 1), 0);
  const shippingFee = 99;
  const grandTotal = Math.max(0, subtotal + shippingFee - appliedDiscount);

  React.useEffect(() => {
    if (!open) {
      setStep('checkout');
      setError('');
      setLoading(false);
    }
  }, [open]);

  if (!open) return null;

  const handleApplyCoupon = (e) => {
    e.preventDefault();
    const code = couponCode.trim().toUpperCase();
    if (!code) return;
    if (code === 'APEX500' || code === 'WELCOME') {
      setAppliedDiscount(500);
      setCouponMsg('Voucher applied! Rs 500 discount added.');
      setError('');
    } else if (code === 'SUPERDEAL') {
      setAppliedDiscount(1000);
      setCouponMsg('Mega Voucher applied! Rs 1,000 discount added.');
      setError('');
    } else {
      setCouponMsg('');
      setError('Invalid voucher code. Try "APEX500" or "SUPERDEAL".');
    }
  };

  const handlePlaceOrder = async (e) => {
    e.preventDefault();
    if (!fullName.trim() || !phone.trim() || !address.trim() || !city.trim()) {
      setError('Please fill in all delivery details.');
      return;
    }

    setLoading(true);
    setError('');

    try {
      const orderPayload = {
        customer_name: fullName,
        phone,
        city,
        address,
        address_type: addressType,
        payment_method: paymentMethod.toUpperCase(),
        total_amount: grandTotal,
        items: items,
        order_status: 'Placed'
      };

      const response = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(orderPayload)
      });

      const orderResult = response.ok ? await response.json() : null;
      const orderId = orderResult?.order?.id || Math.floor(100000 + Math.random() * 900000);

      const orderSummaryObj = {
        id: orderId,
        customerName: fullName,
        phone,
        city,
        address: `${address}, ${city}`,
        deliverySpeed,
        paymentMethod: paymentMethod === 'cod' ? 'Cash on Delivery' : paymentMethod === 'wallet' ? 'JazzCash / EasyPaisa' : 'Credit / Debit Card',
        subtotal,
        shippingFee,
        discount: appliedDiscount,
        totalAmount: grandTotal,
        items,
        date: new Date().toLocaleDateString('en-PK', { day: 'numeric', month: 'short', year: 'numeric' })
      };

      setPlacedOrderData(orderSummaryObj);
      setStep('success');
      if (onOrderPlaced) onOrderPlaced(orderSummaryObj);
    } catch (err) {
      setError('Order placement simulated locally. Order confirmed!');
      setPlacedOrderData({
        id: Math.floor(100000 + Math.random() * 900000),
        customerName: fullName,
        phone,
        city,
        address: `${address}, ${city}`,
        deliverySpeed,
        paymentMethod: paymentMethod === 'cod' ? 'Cash on Delivery' : paymentMethod === 'wallet' ? 'Mobile Wallet' : 'Card',
        subtotal,
        shippingFee,
        discount: appliedDiscount,
        totalAmount: grandTotal,
        items,
        date: new Date().toLocaleDateString('en-PK', { day: 'numeric', month: 'short', year: 'numeric' })
      });
      setStep('success');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[75] flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-3 sm:p-4 md:p-6 overflow-y-auto">
      <button
        type="button"
        className="absolute inset-0 h-full w-full cursor-default"
        aria-label="Close checkout overlay"
        onClick={onClose}
      />

      <section className="relative z-10 w-full max-w-4xl overflow-hidden rounded-2xl bg-white shadow-2xl border border-emerald-100 my-auto">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 bg-emerald-950 px-6 py-4 text-white">
          <div className="flex items-center gap-3">
            <div className="rounded-xl bg-emerald-900/90 p-2.5 text-emerald-300 ring-1 ring-emerald-700/60 shadow-xs flex items-center justify-center">
              <ShoppingCart size={20} />
            </div>
            <div>
              <span className="text-[10px] font-black uppercase tracking-widest text-emerald-300">
                {items.length === 0 ? 'Shopping Cart' : 'Secure Express Checkout'}
              </span>
              <h2 className="text-base font-extrabold text-white">
                {step === 'checkout' ? (items.length === 0 ? 'Your Shopping Cart' : 'Complete Your Order') : 'Order Confirmed!'}
              </h2>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="inline-flex h-8 w-8 items-center justify-center rounded-lg bg-white/10 text-white hover:bg-white/20 transition cursor-pointer"
            aria-label="Close modal"
          >
            <X size={18} />
          </button>
        </div>

        {/* STEP 1: CHECKOUT FORM & SUMMARY */}
        {step === 'checkout' ? (
          items.length === 0 ? (
            <div className="flex flex-col items-center justify-center p-8 sm:p-14 text-center space-y-4 my-auto min-h-[350px]">
              <div className="flex h-20 w-20 items-center justify-center rounded-full bg-emerald-50 text-emerald-600 ring-8 ring-emerald-50/50">
                <ShoppingCart size={40} className="text-emerald-600" />
              </div>
              <div className="space-y-1">
                <h3 className="text-xl font-extrabold text-slate-900">Your cart is empty.</h3>
                <p className="text-xs text-slate-500 max-w-xs mx-auto">
                  Looks like you haven't added any products to your cart yet.
                </p>
              </div>
              <button
                type="button"
                onClick={onClose}
                className="mt-2 inline-flex items-center justify-center gap-2 px-6 py-2.5 rounded-xl bg-emerald-600 font-bold text-xs uppercase tracking-wider text-white shadow-md hover:bg-emerald-700 transition active:scale-95 cursor-pointer"
              >
                <span>Continue Shopping</span>
              </button>
            </div>
          ) : (
            <div className="grid lg:grid-cols-[1.1fr_0.9fr] max-h-[80vh] overflow-y-auto">
            {/* Left Form Column */}
            <div className="p-5 sm:p-6 space-y-5 border-b lg:border-b-0 lg:border-r border-slate-100">
              {error ? (
                <div className="flex items-center gap-2 rounded-xl bg-red-50 p-3 border border-red-200 text-xs text-red-700">
                  <AlertCircle size={16} className="shrink-0 text-red-600" />
                  <span>{error}</span>
                </div>
              ) : null}

              {/* SECTION: SHIPPING ADDRESS */}
              <div>
                <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                  <h3 className="text-xs font-black uppercase tracking-wider text-emerald-800 flex items-center gap-1.5">
                    <MapPin size={16} />
                    <span>1. Delivery Address</span>
                  </h3>
                  <div className="flex gap-1">
                    {['Home', 'Office'].map((tag) => (
                      <button
                        key={tag}
                        type="button"
                        onClick={() => setAddressType(tag)}
                        className={`px-2.5 py-0.5 rounded-md text-[11px] font-bold transition ${
                          addressType === tag
                            ? 'bg-emerald-600 text-white'
                            : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                        }`}
                      >
                        {tag === 'Home' ? <Home size={11} className="inline mr-1" /> : <Building2 size={11} className="inline mr-1" />}
                        {tag}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="mt-3 grid gap-3 sm:grid-cols-2">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">Full Name</label>
                    <div className="relative flex items-center">
                      <User size={14} className="absolute left-2.5 text-slate-400" />
                      <input
                        type="text"
                        value={fullName}
                        onChange={(e) => setFullName(e.target.value)}
                        className="w-full h-9 pl-8 pr-2 text-xs bg-slate-50 border border-slate-200 rounded-lg outline-none focus:bg-white focus:border-emerald-600"
                        placeholder="e.g. Muhammad Ali"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">Mobile Phone</label>
                    <div className="relative flex items-center">
                      <Phone size={14} className="absolute left-2.5 text-slate-400" />
                      <input
                        type="text"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        className="w-full h-9 pl-8 pr-2 text-xs bg-slate-50 border border-slate-200 rounded-lg outline-none focus:bg-white focus:border-emerald-600"
                        placeholder="e.g. 0300-1234567"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">City</label>
                    <select
                      value={city}
                      onChange={(e) => setCity(e.target.value)}
                      className="w-full h-9 px-2.5 text-xs bg-slate-50 border border-slate-200 rounded-lg outline-none focus:bg-white focus:border-emerald-600"
                    >
                      <option value="Lahore">Lahore</option>
                      <option value="Karachi">Karachi</option>
                      <option value="Islamabad">Islamabad</option>
                      <option value="Rawalpindi">Rawalpindi</option>
                      <option value="Faisalabad">Faisalabad</option>
                      <option value="Multan">Multan</option>
                      <option value="Peshawar">Peshawar</option>
                      <option value="Quetta">Quetta</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">Complete Address</label>
                    <input
                      type="text"
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                      className="w-full h-9 px-2.5 text-xs bg-slate-50 border border-slate-200 rounded-lg outline-none focus:bg-white focus:border-emerald-600"
                      placeholder="Street, House/Flat No, Block"
                    />
                  </div>
                </div>
              </div>

              {/* SECTION: DELIVERY OPTIONS */}
              <div>
                <h3 className="text-xs font-black uppercase tracking-wider text-emerald-800 pb-2 border-b border-slate-100 flex items-center gap-1.5">
                  <Truck size={16} />
                  <span>2. Delivery Options</span>
                </h3>

                <div className="mt-3">
                  <div
                    className="flex items-center gap-2.5 p-3.5 rounded-xl border border-emerald-600 bg-emerald-50/70 text-emerald-950 shadow-xs"
                  >
                    <input
                      type="radio"
                      name="delivery"
                      checked={true}
                      readOnly
                      className="text-emerald-600 focus:ring-emerald-500"
                    />
                    <div>
                      <p className="text-xs font-bold text-slate-900">Standard Delivery</p>
                      <p className="text-[11px] text-slate-600">2 to 4 Days • Rs 99</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* SECTION: PAYMENT METHOD */}
              <div>
                <h3 className="text-xs font-black uppercase tracking-wider text-emerald-800 pb-2 border-b border-slate-100 flex items-center gap-1.5">
                  <CreditCard size={16} />
                  <span>3. Payment Method</span>
                </h3>

                <div className="mt-3 space-y-2">
                  {/* Option 1: EasyPaisa & JazzCash */}
                  <label
                    onClick={() => setPaymentMethod('wallet')}
                    className={`flex flex-col p-3 rounded-xl border cursor-pointer transition ${
                      paymentMethod === 'wallet'
                        ? 'border-emerald-600 bg-emerald-50/70 text-emerald-950 shadow-xs'
                        : 'border-slate-200 bg-white hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <input
                          type="radio"
                          name="payment"
                          checked={paymentMethod === 'wallet'}
                          onChange={() => setPaymentMethod('wallet')}
                          className="text-emerald-600 focus:ring-emerald-500"
                        />
                        <div>
                          <p className="text-xs font-bold">EasyPaisa / JazzCash</p>
                          <p className="text-[10px] text-slate-500">Pay via EasyPaisa or JazzCash Mobile Account</p>
                        </div>
                      </div>
                      <span className="rounded bg-emerald-100 px-2 py-0.5 text-[10px] font-bold text-emerald-800">
                        Easy & Fast
                      </span>
                    </div>

                    {paymentMethod === 'wallet' ? (
                      <div className="mt-2.5 pt-2 border-t border-emerald-200/60">
                        <input
                          type="text"
                          value={walletPhone}
                          onChange={(e) => setWalletPhone(e.target.value)}
                          placeholder="Enter EasyPaisa / JazzCash Mobile Number (e.g. 03001234567)"
                          className="w-full h-8 px-2.5 text-xs bg-white border border-slate-200 rounded-lg outline-none focus:border-emerald-600"
                        />
                      </div>
                    ) : null}
                  </label>

                  {/* Option 2: Cash on Delivery (COD) */}
                  <label
                    onClick={() => setPaymentMethod('cod')}
                    className={`flex items-center justify-between p-3 rounded-xl border cursor-pointer transition ${
                      paymentMethod === 'cod'
                        ? 'border-emerald-600 bg-emerald-50/70 text-emerald-950 shadow-xs'
                        : 'border-slate-200 bg-white hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <input
                        type="radio"
                        name="payment"
                        checked={paymentMethod === 'cod'}
                        onChange={() => setPaymentMethod('cod')}
                        className="text-emerald-600 focus:ring-emerald-500"
                      />
                      <div>
                        <p className="text-xs font-bold">Cash on Delivery (COD)</p>
                        <p className="text-[10px] text-slate-500">Pay cash upon order arrival at your doorstep</p>
                      </div>
                    </div>
                    <span className="rounded bg-slate-100 px-2 py-0.5 text-[10px] font-bold text-slate-700">
                      Standard COD
                    </span>
                  </label>

                  {/* Option 3: Visa / Credit / Debit Card */}
                  <label
                    onClick={() => setPaymentMethod('card')}
                    className={`flex flex-col p-3 rounded-xl border cursor-pointer transition ${
                      paymentMethod === 'card'
                        ? 'border-emerald-600 bg-emerald-50/70 text-emerald-950 shadow-xs'
                        : 'border-slate-200 bg-white hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <input
                          type="radio"
                          name="payment"
                          checked={paymentMethod === 'card'}
                          onChange={() => setPaymentMethod('card')}
                          className="text-emerald-600 focus:ring-emerald-500"
                        />
                        <div>
                          <p className="text-xs font-bold">Visa / Debit & Credit Card</p>
                          <p className="text-[10px] text-slate-500">Visa, Mastercard & PayPak</p>
                        </div>
                      </div>
                      <ShieldCheck size={16} className="text-emerald-600" />
                    </div>

                    {paymentMethod === 'card' ? (
                      <div className="mt-2.5 pt-2 border-t border-emerald-200/60 space-y-2">
                        <input
                          type="text"
                          value={cardNumber}
                          onChange={(e) => setCardNumber(e.target.value)}
                          placeholder="Visa / Mastercard Number (xxxx xxxx xxxx xxxx)"
                          className="w-full h-8 px-2.5 text-xs bg-white border border-slate-200 rounded-lg outline-none focus:border-emerald-600"
                        />
                        <div className="grid grid-cols-2 gap-2">
                          <input
                            type="text"
                            value={cardExpiry}
                            onChange={(e) => setCardExpiry(e.target.value)}
                            placeholder="MM / YY"
                            className="h-8 px-2.5 text-xs bg-white border border-slate-200 rounded-lg outline-none focus:border-emerald-600"
                          />
                          <input
                            type="text"
                            value={cardCvc}
                            onChange={(e) => setCardCvc(e.target.value)}
                            placeholder="CVV / CVC"
                            className="h-8 px-2.5 text-xs bg-white border border-slate-200 rounded-lg outline-none focus:border-emerald-600"
                          />
                        </div>
                      </div>
                    ) : null}
                  </label>
                </div>
              </div>
            </div>

            {/* Right Summary Column */}
            <div className="p-5 sm:p-6 bg-slate-50 flex flex-col justify-between space-y-4">
              <div>
                <h3 className="text-xs font-black uppercase tracking-wider text-slate-800 pb-3 border-b border-slate-200 flex items-center justify-between">
                  <span>Order Items ({items.length})</span>
                  <ShoppingBag size={16} className="text-emerald-700" />
                </h3>

                {/* Items List */}
                <div className="mt-3 space-y-2.5 max-h-48 overflow-y-auto pr-1">
                  {items.map((item, idx) => (
                    <div key={item.id || idx} className="flex items-center gap-3 bg-white p-2.5 rounded-xl border border-slate-200">
                      <img
                        src={item.image}
                        alt={item.title}
                        className="h-12 w-12 rounded-lg object-cover bg-slate-100"
                      />
                      <div className="min-w-0 flex-1">
                        <p className="text-xs font-bold text-slate-900 truncate">{item.title}</p>
                        <p className="text-[11px] text-slate-500">Qty: {item.qty || 1}</p>
                      </div>
                      <span className="text-xs font-black text-slate-900">
                        Rs {((item.price || 0) * (item.qty || 1)).toLocaleString('en-PK')}
                      </span>
                    </div>
                  ))}
                </div>

                {/* Voucher Section */}
                <div className="mt-4 pt-3 border-t border-slate-200">
                  <form onSubmit={handleApplyCoupon} className="flex gap-1.5">
                    <div className="relative flex-1 flex items-center">
                      <Tag size={14} className="absolute left-2.5 text-slate-400" />
                      <input
                        type="text"
                        value={couponCode}
                        onChange={(e) => setCouponCode(e.target.value)}
                        placeholder="Voucher Code (e.g. APEX500)"
                        className="w-full h-9 pl-8 pr-2 text-xs uppercase bg-white border border-slate-200 rounded-lg outline-none focus:border-emerald-600"
                      />
                    </div>
                    <button
                      type="submit"
                      className="h-9 px-3.5 bg-emerald-600 text-white font-bold text-xs rounded-lg hover:bg-emerald-700 transition"
                    >
                      Apply
                    </button>
                  </form>
                  {couponMsg ? (
                    <p className="mt-1 text-[11px] font-semibold text-emerald-700 flex items-center gap-1">
                      <CheckCircle2 size={13} /> {couponMsg}
                    </p>
                  ) : null}
                </div>

                {/* Cost Breakdown */}
                <div className="mt-4 space-y-2 text-xs pt-3 border-t border-slate-200 text-slate-600">
                  <div className="flex justify-between">
                    <span>Subtotal</span>
                    <span className="font-semibold text-slate-900">Rs {subtotal.toLocaleString('en-PK')}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Shipping Fee</span>
                    <span className="font-semibold text-slate-900">Rs {shippingFee.toLocaleString('en-PK')}</span>
                  </div>
                  {appliedDiscount > 0 ? (
                    <div className="flex justify-between text-emerald-700 font-bold">
                      <span>Voucher Discount</span>
                      <span>- Rs {appliedDiscount.toLocaleString('en-PK')}</span>
                    </div>
                  ) : null}
                  <div className="flex justify-between pt-2 border-t border-slate-300 text-sm font-black text-slate-900">
                    <span>Total Amount</span>
                    <span className="text-emerald-700 text-base">Rs {grandTotal.toLocaleString('en-PK')}</span>
                  </div>
                </div>
              </div>

              {/* Submit CTA */}
              <div className="pt-2">
                <button
                  type="button"
                  onClick={handlePlaceOrder}
                  disabled={loading}
                  className="w-full h-12 inline-flex items-center justify-center gap-2 rounded-xl bg-emerald-600 font-bold text-xs uppercase tracking-wider text-white shadow-lg shadow-emerald-900/20 transition hover:bg-emerald-700 active:scale-[0.99] disabled:opacity-70"
                >
                  <PackageCheck size={18} />
                  <span>{loading ? 'Processing Order...' : `Place Order (Rs ${grandTotal.toLocaleString('en-PK')})`}</span>
                </button>

                <div className="mt-2 text-center text-[10px] text-slate-400 flex items-center justify-center gap-1">
                  <ShieldCheck size={13} className="text-emerald-600" />
                  <span>256-Bit Encrypted Secure Checkout • 100% Buyer Protection</span>
                </div>
              </div>
            </div>
          </div>
        )
      ) : (
          /* STEP 2: ORDER CONFIRMATION SUCCESS VIEW */
          <div className="p-6 sm:p-10 text-center space-y-6">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-emerald-100 text-emerald-600 animate-bounce">
              <CheckCircle2 size={36} />
            </div>

            <div className="space-y-1">
              <span className="text-xs font-bold uppercase tracking-widest text-emerald-700">
                Order #{placedOrderData?.id} Placed Successfully
              </span>
              <h3 className="text-2xl font-black text-slate-900">Thank You For Shopping!</h3>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                We have received your order. A confirmation SMS and email have been sent to your details.
              </p>
            </div>

            {/* Order Progress Status Timeline */}
            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 max-w-xl mx-auto text-left space-y-3">
              <div className="flex justify-between items-center text-xs">
                <span className="font-bold text-slate-700">Estimated Delivery:</span>
                <span className="font-black text-emerald-800">
                  2 to 4 Days
                </span>
              </div>

              {/* Progress Steps */}
              <div className="grid grid-cols-4 gap-2 pt-2 text-center text-[10px]">
                <div className="flex flex-col items-center">
                  <div className="h-7 w-7 rounded-full bg-emerald-600 text-white flex items-center justify-center font-bold">1</div>
                  <span className="mt-1 font-bold text-emerald-800">Placed</span>
                </div>
                <div className="flex flex-col items-center">
                  <div className="h-7 w-7 rounded-full bg-slate-200 text-slate-600 flex items-center justify-center font-bold">2</div>
                  <span className="mt-1 text-slate-500">Processing</span>
                </div>
                <div className="flex flex-col items-center">
                  <div className="h-7 w-7 rounded-full bg-slate-200 text-slate-600 flex items-center justify-center font-bold">3</div>
                  <span className="mt-1 text-slate-500">Shipped</span>
                </div>
                <div className="flex flex-col items-center">
                  <div className="h-7 w-7 rounded-full bg-slate-200 text-slate-600 flex items-center justify-center font-bold">4</div>
                  <span className="mt-1 text-slate-500">Delivered</span>
                </div>
              </div>

              <div className="border-t border-slate-200 pt-3 text-xs space-y-1 text-slate-600">
                <p><strong>Deliver To:</strong> {placedOrderData?.customerName} ({placedOrderData?.phone})</p>
                <p><strong>Address:</strong> {placedOrderData?.address}</p>
                <p><strong>Payment Method:</strong> {placedOrderData?.paymentMethod}</p>
                <p><strong>Total Amount:</strong> <span className="font-black text-emerald-700">Rs {placedOrderData?.totalAmount.toLocaleString('en-PK')}</span></p>
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="px-6 h-11 inline-flex items-center gap-2 rounded-xl bg-emerald-600 text-white font-bold text-xs uppercase tracking-wider hover:bg-emerald-700 transition"
              >
                <ShoppingBag size={16} />
                <span>Continue Shopping</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  alert(`Invoice for Order #${placedOrderData?.id} downloaded!`);
                }}
                className="px-5 h-11 inline-flex items-center gap-2 rounded-xl border border-slate-300 bg-white text-slate-700 font-bold text-xs uppercase hover:bg-slate-50 transition"
              >
                <Download size={16} />
                <span>Download Invoice</span>
              </button>
            </div>
          </div>
        )}
      </section>
    </div>
  );
}
