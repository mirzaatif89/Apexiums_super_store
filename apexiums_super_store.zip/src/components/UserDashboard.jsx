import React from 'react';
import OrdersSection from './OrdersSection';
import Footer from './Footer';
import { footerSections, paymentMethods } from '../data/storeData';
import {
  AlertCircle,
  Bell,
  Building,
  CheckCircle2,
  ChevronRight,
  Clock,
  CreditCard,
  Download,
  Eye,
  Heart,
  Home,
  KeyRound,
  LogOut,
  MapPin,
  PackageCheck,
  PackageSearch,
  Phone,
  Plus,
  RefreshCw,
  Search,
  ShieldCheck,
  ShoppingBag,
  ShoppingCart,
  Star,
  Trash2,
  Truck,
  User,
  UserCheck,
  UserCircle2,
  X
} from 'lucide-react';

const money = (value) => `Rs ${Number(value || 0).toLocaleString('en-PK')}`;

function apiFetch(path, session, options = {}) {
  const headers = {
    'Content-Type': 'application/json',
    ...(session?.role ? { 'x-user-role': session.role } : {}),
    ...(session?.businessId ? { 'x-business-id': String(session.businessId) } : {})
  };
  return fetch(path, { ...options, headers: { ...headers, ...(options.headers || {}) } });
}

export default function UserDashboard({ session, storeName, logoSrc, onLogout }) {
  const [activeTab, setActiveTab] = React.useState('orders'); // 'orders' | 'profile' | 'addresses' | 'wishlist' | 'payments' | 'notifications' | 'security'
  const [orders, setOrders] = React.useState([]);
  const [products, setProducts] = React.useState([]);
  const [notifications, setNotifications] = React.useState([]);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState('');
  const [successMsg, setSuccessMsg] = React.useState('');

  // Order Details Modal state
  const [selectedOrder, setSelectedOrder] = React.useState(null);
  const [orderFilter, setOrderFilter] = React.useState('All'); // 'All' | 'Processing' | 'Shipped' | 'Delivered' | 'Cancelled'
  const [searchOrderQuery, setSearchOrderQuery] = React.useState('');

  // Personal Info form
  const [profileName, setProfileName] = React.useState(session?.name || 'Muhammad Ali');
  const [profileEmail, setProfileEmail] = React.useState(session?.email || 'customer@demo.com');
  const [profilePhone, setProfilePhone] = React.useState('0300-1234567');
  const [avatarSrc, setAvatarSrc] = React.useState(
    'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80'
  );

  // Address Management state
  const [addresses, setAddresses] = React.useState([
    {
      id: 1,
      type: 'Home',
      isPrimary: true,
      name: 'Muhammad Ali',
      phone: '0300-1234567',
      address: 'House #42, Block B, Johar Town, Lahore'
    },
    {
      id: 2,
      type: 'Office',
      isPrimary: false,
      name: 'Muhammad Ali',
      phone: '0321-9876543',
      address: 'Suite #502, Apex Towers, Gulberg III, Lahore'
    }
  ]);
  const [showAddressModal, setShowAddressModal] = React.useState(false);
  const [newAddressType, setNewAddressType] = React.useState('Home');
  const [newAddressName, setNewAddressName] = React.useState('');
  const [newAddressPhone, setNewAddressPhone] = React.useState('');
  const [newAddressDetails, setNewAddressDetails] = React.useState('');

  // Wishlist items
  const [wishlist, setWishlist] = React.useState([
    {
      id: 101,
      title: 'Bluetooth Earbuds Pro Max',
      price: 3499,
      originalPrice: 5499,
      image: 'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?auto=format&fit=crop&w=400&q=80',
      rating: 4.8
    },
    {
      id: 102,
      title: 'Minimal Smart Watch',
      price: 5999,
      originalPrice: 8999,
      image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=400&q=80',
      rating: 4.7
    }
  ]);

  // Payment Methods
  const [savedPayments, setSavedPayments] = React.useState([
    { id: 1, type: 'JazzCash', number: '0300****567', isDefault: true },
    { id: 2, type: 'Visa Card', number: '**** **** **** 4242', isDefault: false }
  ]);

  // Security Settings
  const [oldPassword, setOldPassword] = React.useState('');
  const [newPassword, setNewPassword] = React.useState('');
  const [twoFactorEnabled, setTwoFactorEnabled] = React.useState(false);

  const loadData = React.useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const [productRes, orderRes, notificationRes] = await Promise.all([
        apiFetch('/api/products?limit=10', session),
        apiFetch('/api/orders?limit=10', session),
        apiFetch('/api/notifications?limit=5', session)
      ]);

      const [productData, orderData, notificationData] = await Promise.all([
        productRes.json(),
        orderRes.json(),
        notificationRes.json()
      ]);

      setProducts(productData.rows || []);
      
      // If API returns orders, enrich with mock statuses for marketplace order experience
      const fetchedOrders = (orderData.rows || []).map((ord, idx) => ({
        ...ord,
        order_status: ord.order_status || (idx % 3 === 0 ? 'Delivered' : idx % 2 === 0 ? 'Shipped' : 'Processing'),
        estimated_delivery: '2-4 Business Days',
        shipping_address: 'House #42, Block B, Johar Town, Lahore',
        payment_method: 'Cash on Delivery (COD)'
      }));

      // Fallback default sample orders if database empty
      if (fetchedOrders.length === 0) {
        setOrders([
          {
            id: 1001,
            customer_name: session?.name || 'Muhammad Ali',
            total_amount: 9498,
            order_status: 'Processing',
            created_at: new Date().toISOString(),
            estimated_delivery: 'Tomorrow by 5:00 PM',
            shipping_address: 'House #42, Block B, Johar Town, Lahore',
            payment_method: 'Cash on Delivery (COD)',
            items: [
              { title: 'Bluetooth Earbuds Pro Max', qty: 1, price: 3499, image: 'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?auto=format&fit=crop&w=400&q=80' },
              { title: 'Minimal Smart Watch', qty: 1, price: 5999, image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=400&q=80' }
            ]
          },
          {
            id: 1002,
            customer_name: session?.name || 'Muhammad Ali',
            total_amount: 3999,
            order_status: 'Delivered',
            created_at: new Date(Date.now() - 86400000 * 3).toISOString(),
            estimated_delivery: 'Delivered on Aug 2, 2026',
            shipping_address: 'House #42, Block B, Johar Town, Lahore',
            payment_method: 'JazzCash Wallet',
            items: [
              { title: 'Travel Backpack', qty: 1, price: 3999, image: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=400&q=80' }
            ]
          }
        ]);
      } else {
        setOrders(fetchedOrders);
      }

      setNotifications(notificationData.rows || []);
    } catch (err) {
      setError('Loaded dashboard offline preview.');
    } finally {
      setLoading(false);
    }
  }, [session]);

  React.useEffect(() => {
    loadData();
  }, [loadData]);

  // Order filtering logic
  const filteredOrders = orders.filter((order) => {
    const matchesFilter = orderFilter === 'All' || order.order_status?.toLowerCase() === orderFilter.toLowerCase();
    const matchesSearch =
      !searchOrderQuery ||
      String(order.id).includes(searchOrderQuery) ||
      (order.customer_name && order.customer_name.toLowerCase().includes(searchOrderQuery.toLowerCase()));
    return matchesFilter && matchesSearch;
  });

  const handleSaveProfile = (e) => {
    e.preventDefault();
    setSuccessMsg('Profile updated successfully!');
    setTimeout(() => setSuccessMsg(''), 3000);
  };

  const handleAddAddress = (e) => {
    e.preventDefault();
    if (!newAddressName || !newAddressPhone || !newAddressDetails) return;
    const newAddr = {
      id: Date.now(),
      type: newAddressType,
      isPrimary: addresses.length === 0,
      name: newAddressName,
      phone: newAddressPhone,
      address: newAddressDetails
    };
    setAddresses([...addresses, newAddr]);
    setShowAddressModal(false);
    setNewAddressName('');
    setNewAddressPhone('');
    setNewAddressDetails('');
    setSuccessMsg('New delivery address added!');
    setTimeout(() => setSuccessMsg(''), 3000);
  };

  const handleSetPrimaryAddress = (id) => {
    setAddresses(addresses.map((addr) => ({ ...addr, isPrimary: addr.id === id })));
  };

  const handleDeleteAddress = (id) => {
    setAddresses(addresses.filter((addr) => addr.id !== id));
  };

  const handleRemoveWishlist = (id) => {
    setWishlist(wishlist.filter((item) => item.id !== id));
  };

  const handleChangePassword = (e) => {
    e.preventDefault();
    if (!oldPassword || !newPassword) {
      setError('Please fill in both old and new passwords.');
      return;
    }
    setError('');
    setSuccessMsg('Password updated successfully!');
    setOldPassword('');
    setNewPassword('');
    setTimeout(() => setSuccessMsg(''), 3000);
  };

  return (
    <div className="flex flex-col min-h-screen bg-slate-100 text-slate-900 font-sans">
      {/* Customer Header Bar */}
      <header className="sticky top-0 z-40 bg-white border-b border-emerald-100 shadow-xs">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3 sm:px-6">
          <div className="flex items-center gap-3">
            <div className="rounded-xl bg-white p-1 border border-slate-200 shadow-2xs">
              <img src={logoSrc} alt={storeName} className="h-8 sm:h-9 w-auto object-contain" />
            </div>
            <div>
              <span className="text-[10px] font-black uppercase tracking-widest text-emerald-700">Customer Dashboard</span>
              <h1 className="text-sm sm:text-base font-black text-slate-900">
                Welcome, {profileName}
              </h1>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onLogout}
              className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-red-200 bg-red-50 px-3 text-xs font-bold text-red-700 hover:bg-red-100 transition"
            >
              <LogOut size={15} />
              <span>Sign Out</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <div className="flex-1 mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8 w-full">
        {/* Status Banners */}
        {error ? (
          <div className="mb-4 flex items-center gap-2 rounded-xl bg-red-50 p-3 border border-red-200 text-xs text-red-700">
            <AlertCircle size={16} className="shrink-0 text-red-600" />
            <span>{error}</span>
          </div>
        ) : null}

        {successMsg ? (
          <div className="mb-4 flex items-center gap-2 rounded-xl bg-emerald-50 p-3 border border-emerald-200 text-xs text-emerald-800">
            <CheckCircle2 size={16} className="shrink-0 text-emerald-600" />
            <span>{successMsg}</span>
          </div>
        ) : null}

        <div className="grid lg:grid-cols-[280px_1fr] gap-6 items-start">
          {/* Sidebar Navigation */}
          <aside className="bg-white rounded-2xl border border-emerald-100 p-4 shadow-sm space-y-6">
            {/* User Profile Summary */}
            <div className="flex items-center gap-3 p-3 rounded-xl bg-emerald-50/70 border border-emerald-100">
              <img
                src={avatarSrc}
                alt={profileName}
                className="h-12 w-12 rounded-full object-cover border-2 border-emerald-600 shadow-2xs"
              />
              <div className="min-w-0 flex-1">
                <h3 className="text-xs font-black text-slate-900 truncate">{profileName}</h3>
                <p className="text-[11px] text-slate-500 truncate">{profileEmail}</p>
                <span className="inline-block mt-1 px-2 py-0.5 rounded bg-emerald-600 text-[9px] font-extrabold uppercase tracking-wider text-white">
                  Verified Member
                </span>
              </div>
            </div>

            {/* Navigation Tabs */}
            <nav className="space-y-1">
              {[
                { id: 'orders', label: 'My Orders', icon: PackageSearch, count: orders.length },
                { id: 'profile', label: 'Profile Information', icon: User },
                { id: 'addresses', label: 'Delivery Addresses', icon: MapPin, count: addresses.length },
                { id: 'wishlist', label: 'My Wishlist', icon: Heart, count: wishlist.length },
                { id: 'payments', label: 'Payment Options', icon: CreditCard, count: savedPayments.length },
                { id: 'notifications', label: 'Notifications', icon: Bell, count: notifications.length },
                { id: 'security', label: 'Security & Password', icon: KeyRound }
              ].map((tab) => {
                const Icon = tab.icon;
                const active = activeTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => setActiveTab(tab.id)}
                    className={`w-full flex items-center justify-between p-2.5 rounded-xl text-xs font-bold transition ${
                      active
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <Icon size={16} />
                      <span>{tab.label}</span>
                    </div>
                    {tab.count !== undefined ? (
                      <span
                        className={`px-1.5 py-0.5 rounded-full text-[10px] ${
                          active ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-600'
                        }`}
                      >
                        {tab.count}
                      </span>
                    ) : null}
                  </button>
                );
              })}
            </nav>

            {/* Support Box */}
            <div className="p-3.5 rounded-xl bg-slate-900 text-white space-y-2">
              <p className="text-[11px] font-bold text-emerald-400 uppercase tracking-wider">Apexiums Support</p>
              <p className="text-xs text-slate-300">Need help with an existing order or refund?</p>
              <button
                type="button"
                onClick={() => alert('Customer support helpline: 021-111-132-729')}
                className="w-full py-1.5 rounded-lg bg-emerald-600 text-[11px] font-bold text-white hover:bg-emerald-700 transition"
              >
                Contact Customer Care
              </button>
            </div>
          </aside>

          {/* Main Workspace Area */}
          <main className="bg-white rounded-2xl border border-emerald-100 p-5 sm:p-6 shadow-sm min-h-[500px]">
            {/* TAB 1: MY ORDERS */}
            {activeTab === 'orders' ? (
              <OrdersSection
                orders={orders}
                setOrders={setOrders}
                session={session}
                storeName={storeName}
                logoSrc={logoSrc}
              />
            ) : null}

            {/* TAB 2: PROFILE INFORMATION */}
            {activeTab === 'profile' ? (
              <div className="space-y-6">
                <div className="pb-4 border-b border-slate-100">
                  <h2 className="text-lg font-black text-slate-900">Profile Information</h2>
                  <p className="text-xs text-slate-500">Manage your account details and contact information</p>
                </div>

                <form onSubmit={handleSaveProfile} className="max-w-xl space-y-4">
                  {/* Avatar upload representation */}
                  <div className="flex items-center gap-4 p-3 bg-slate-50 rounded-2xl border border-slate-200">
                    <img src={avatarSrc} alt="Avatar" className="h-16 w-16 rounded-full object-cover border-2 border-emerald-600" />
                    <div>
                      <p className="text-xs font-bold text-slate-800">Profile Avatar</p>
                      <p className="text-[11px] text-slate-500 mb-2">JPG or PNG under 2MB</p>
                      <button
                        type="button"
                        onClick={() => {
                          const newUrl = prompt('Enter image URL for avatar:', avatarSrc);
                          if (newUrl) setAvatarSrc(newUrl);
                        }}
                        className="px-3 py-1 bg-white border border-slate-300 text-[11px] font-bold rounded-lg hover:bg-slate-100 transition"
                      >
                        Change Photo
                      </button>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Full Name</label>
                    <input
                      type="text"
                      value={profileName}
                      onChange={(e) => setProfileName(e.target.value)}
                      className="w-full h-10 px-3 text-xs bg-slate-50 border border-slate-200 rounded-xl outline-none focus:bg-white focus:border-emerald-600"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Email Address</label>
                    <input
                      type="email"
                      value={profileEmail}
                      onChange={(e) => setProfileEmail(e.target.value)}
                      className="w-full h-10 px-3 text-xs bg-slate-50 border border-slate-200 rounded-xl outline-none focus:bg-white focus:border-emerald-600"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Mobile Phone Number</label>
                    <input
                      type="text"
                      value={profilePhone}
                      onChange={(e) => setProfilePhone(e.target.value)}
                      className="w-full h-10 px-3 text-xs bg-slate-50 border border-slate-200 rounded-xl outline-none focus:bg-white focus:border-emerald-600"
                    />
                  </div>

                  <button
                    type="submit"
                    className="px-6 h-11 bg-emerald-600 text-white text-xs font-bold rounded-xl hover:bg-emerald-700 transition shadow-sm"
                  >
                    Save Changes
                  </button>
                </form>
              </div>
            ) : null}

            {/* TAB 3: DELIVERY ADDRESSES */}
            {activeTab === 'addresses' ? (
              <div className="space-y-5">
                <div className="flex items-center justify-between pb-4 border-b border-slate-100">
                  <div>
                    <h2 className="text-lg font-black text-slate-900">Address Book</h2>
                    <p className="text-xs text-slate-500">Manage saved shipping addresses for faster express checkout</p>
                  </div>

                  <button
                    type="button"
                    onClick={() => setShowAddressModal(true)}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-emerald-600 text-white font-bold text-xs rounded-xl hover:bg-emerald-700 transition shadow-xs"
                  >
                    <Plus size={15} />
                    <span>Add Address</span>
                  </button>
                </div>

                {/* Addresses Grid */}
                <div className="grid gap-4 sm:grid-cols-2">
                  {addresses.map((addr) => (
                    <div
                      key={addr.id}
                      className={`p-4 rounded-2xl border transition ${
                        addr.isPrimary
                          ? 'border-emerald-600 bg-emerald-50/50'
                          : 'border-slate-200 bg-white hover:bg-slate-50'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span className="inline-flex items-center gap-1 text-xs font-black text-slate-900">
                          {addr.type === 'Home' ? <Home size={14} className="text-emerald-700" /> : <Building size={14} className="text-emerald-700" />}
                          {addr.type} Address
                        </span>
                        {addr.isPrimary ? (
                          <span className="px-2 py-0.5 rounded bg-emerald-600 text-[10px] font-extrabold uppercase text-white">
                            DEFAULT
                          </span>
                        ) : (
                          <button
                            type="button"
                            onClick={() => handleSetPrimaryAddress(addr.id)}
                            className="text-[11px] font-bold text-emerald-700 hover:underline"
                          >
                            Set as Primary
                          </button>
                        )}
                      </div>

                      <p className="text-xs font-bold text-slate-800">{addr.name}</p>
                      <p className="text-[11px] text-slate-500 mb-2">{addr.phone}</p>
                      <p className="text-xs text-slate-700 leading-relaxed mb-3">{addr.address}</p>

                      <div className="pt-2 border-t border-slate-200 flex justify-end">
                        <button
                          type="button"
                          onClick={() => handleDeleteAddress(addr.id)}
                          className="inline-flex items-center gap-1 text-[11px] font-bold text-red-600 hover:underline"
                        >
                          <Trash2 size={13} />
                          <span>Remove</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ) : null}

            {/* TAB 4: MY WISHLIST */}
            {activeTab === 'wishlist' ? (
              <div className="space-y-5">
                <div className="pb-4 border-b border-slate-100">
                  <h2 className="text-lg font-black text-slate-900">My Saved Wishlist</h2>
                  <p className="text-xs text-slate-500">Products saved for future purchases</p>
                </div>

                {wishlist.length === 0 ? (
                  <div className="p-10 text-center space-y-3 border border-dashed border-slate-200 rounded-2xl">
                    <Heart size={36} className="mx-auto text-slate-300" />
                    <p className="text-xs font-bold text-slate-600">Your wishlist is empty</p>
                  </div>
                ) : (
                  <div className="grid gap-4 sm:grid-cols-2">
                    {wishlist.map((item) => (
                      <div key={item.id} className="flex gap-3 p-3 rounded-2xl border border-slate-200 bg-slate-50/50">
                        <img src={item.image} alt={item.title} className="h-20 w-20 rounded-xl object-cover bg-white" />
                        <div className="min-w-0 flex-1 flex flex-col justify-between">
                          <div>
                            <h3 className="text-xs font-bold text-slate-900 truncate">{item.title}</h3>
                            <div className="mt-1 flex items-center gap-2">
                              <span className="text-xs font-black text-emerald-800">Rs {item.price.toLocaleString('en-PK')}</span>
                              <span className="text-[10px] text-slate-400 line-through">Rs {item.originalPrice.toLocaleString('en-PK')}</span>
                            </div>
                          </div>

                          <div className="flex items-center justify-between pt-2">
                            <button
                              type="button"
                              onClick={() => alert('Item added to cart!')}
                              className="px-3 py-1 bg-emerald-600 text-white font-bold text-[11px] rounded-lg hover:bg-emerald-700 transition"
                            >
                              Add To Cart
                            </button>
                            <button
                              type="button"
                              onClick={() => handleRemoveWishlist(item.id)}
                              className="text-slate-400 hover:text-red-600 transition"
                            >
                              <Trash2 size={15} />
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ) : null}

            {/* TAB 5: PAYMENT OPTIONS */}
            {activeTab === 'payments' ? (
              <div className="space-y-5">
                <div className="pb-4 border-b border-slate-100">
                  <h2 className="text-lg font-black text-slate-900">Saved Payment Methods</h2>
                  <p className="text-xs text-slate-500">Secure wallet and card options for express checkout</p>
                </div>

                <div className="space-y-3 max-w-lg">
                  {savedPayments.map((pm) => (
                    <div key={pm.id} className="flex items-center justify-between p-4 rounded-xl border border-slate-200 bg-slate-50">
                      <div className="flex items-center gap-3">
                        <CreditCard className="text-emerald-700" size={20} />
                        <div>
                          <p className="text-xs font-bold text-slate-900">{pm.type}</p>
                          <p className="text-[11px] text-slate-500">{pm.number}</p>
                        </div>
                      </div>
                      {pm.isDefault ? (
                        <span className="px-2 py-0.5 rounded bg-emerald-100 text-[10px] font-bold text-emerald-800">
                          Primary
                        </span>
                      ) : null}
                    </div>
                  ))}
                </div>
              </div>
            ) : null}

            {/* TAB 6: NOTIFICATIONS */}
            {activeTab === 'notifications' ? (
              <div className="space-y-5">
                <div className="pb-4 border-b border-slate-100">
                  <h2 className="text-lg font-black text-slate-900">Order Alerts & Offers</h2>
                  <p className="text-xs text-slate-500">Recent status updates and vouchers</p>
                </div>

                <div className="space-y-3">
                  {[
                    { id: 1, title: 'Order #ORD-1001 Processed', msg: 'Your order is packed and ready for courier pickup.', time: '2 hrs ago' },
                    { id: 2, title: 'Summer Flash Deal Voucher', msg: 'Use code APEX500 for Rs 500 discount on electronics.', time: '1 day ago' }
                  ].map((n) => (
                    <div key={n.id} className="p-3.5 rounded-xl border border-slate-200 bg-slate-50">
                      <div className="flex items-center justify-between">
                        <h3 className="text-xs font-bold text-slate-900">{n.title}</h3>
                        <span className="text-[10px] text-slate-400">{n.time}</span>
                      </div>
                      <p className="text-xs text-slate-600 mt-1">{n.msg}</p>
                    </div>
                  ))}
                </div>
              </div>
            ) : null}

            {/* TAB 7: SECURITY */}
            {activeTab === 'security' ? (
              <div className="space-y-6">
                <div className="pb-4 border-b border-slate-100">
                  <h2 className="text-lg font-black text-slate-900">Account Security</h2>
                  <p className="text-xs text-slate-500">Update password and manage security preferences</p>
                </div>

                <form onSubmit={handleChangePassword} className="max-w-md space-y-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Current Password</label>
                    <input
                      type="password"
                      value={oldPassword}
                      onChange={(e) => setOldPassword(e.target.value)}
                      placeholder="Enter current password"
                      className="w-full h-10 px-3 text-xs bg-slate-50 border border-slate-200 rounded-xl outline-none focus:bg-white focus:border-emerald-600"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">New Password</label>
                    <input
                      type="password"
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      placeholder="Enter new password"
                      className="w-full h-10 px-3 text-xs bg-slate-50 border border-slate-200 rounded-xl outline-none focus:bg-white focus:border-emerald-600"
                    />
                  </div>

                  <button
                    type="submit"
                    className="px-6 h-11 bg-emerald-600 text-white font-bold text-xs rounded-xl hover:bg-emerald-700 transition"
                  >
                    Update Password
                  </button>
                </form>
              </div>
            ) : null}
          </main>
        </div>
      </div>

      {/* DETAILED ORDER DETAILS MODAL */}
      {selectedOrder ? (
        <div className="fixed inset-0 z-[80] flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto">
          <button
            type="button"
            className="absolute inset-0 h-full w-full cursor-default"
            aria-label="Close order details"
            onClick={() => setSelectedOrder(null)}
          />

          <div className="relative z-10 w-full max-w-3xl overflow-hidden rounded-2xl bg-white shadow-2xl border border-emerald-100 my-auto">
            {/* Header */}
            <div className="flex items-center justify-between bg-emerald-950 px-6 py-4 text-white">
              <div>
                <span className="text-[10px] font-black uppercase tracking-widest text-emerald-300">
                  Order Details
                </span>
                <h2 className="text-lg font-extrabold text-white">#ORD-{selectedOrder.id}</h2>
              </div>

              <button
                type="button"
                onClick={() => setSelectedOrder(null)}
                className="inline-flex h-8 w-8 items-center justify-center rounded-lg bg-white/10 text-white hover:bg-white/20 transition"
              >
                <X size={18} />
              </button>
            </div>

            <div className="p-6 space-y-6 max-h-[80vh] overflow-y-auto">
              {/* Timeline Progress */}
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-3">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-bold text-slate-700">Estimated Delivery:</span>
                  <span className="font-black text-emerald-800">{selectedOrder.estimated_delivery}</span>
                </div>

                <div className="grid grid-cols-4 gap-2 pt-2 text-center text-[10px]">
                  <div className="flex flex-col items-center">
                    <div className="h-7 w-7 rounded-full bg-emerald-600 text-white flex items-center justify-center font-bold">1</div>
                    <span className="mt-1 font-bold text-emerald-800">Placed</span>
                  </div>
                  <div className="flex flex-col items-center">
                    <div className={`h-7 w-7 rounded-full flex items-center justify-center font-bold ${
                      ['Shipped', 'Delivered'].includes(selectedOrder.order_status) ? 'bg-emerald-600 text-white' : 'bg-slate-200 text-slate-600'
                    }`}>2</div>
                    <span className="mt-1 text-slate-600">Processing</span>
                  </div>
                  <div className="flex flex-col items-center">
                    <div className={`h-7 w-7 rounded-full flex items-center justify-center font-bold ${
                      selectedOrder.order_status === 'Delivered' ? 'bg-emerald-600 text-white' : 'bg-slate-200 text-slate-600'
                    }`}>3</div>
                    <span className="mt-1 text-slate-600">Shipped</span>
                  </div>
                  <div className="flex flex-col items-center">
                    <div className={`h-7 w-7 rounded-full flex items-center justify-center font-bold ${
                      selectedOrder.order_status === 'Delivered' ? 'bg-emerald-600 text-white' : 'bg-slate-200 text-slate-600'
                    }`}>4</div>
                    <span className="mt-1 text-slate-600">Delivered</span>
                  </div>
                </div>
              </div>

              {/* Order Info Grid */}
              <div className="grid sm:grid-cols-2 gap-4 text-xs">
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                  <p className="font-bold text-slate-900 flex items-center gap-1.5">
                    <MapPin size={14} className="text-emerald-600" />
                    <span>Shipping Address</span>
                  </p>
                  <p className="text-slate-700">{selectedOrder.customer_name || profileName}</p>
                  <p className="text-slate-500">{selectedOrder.shipping_address}</p>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                  <p className="font-bold text-slate-900 flex items-center gap-1.5">
                    <CreditCard size={14} className="text-emerald-600" />
                    <span>Payment Method</span>
                  </p>
                  <p className="text-slate-700">{selectedOrder.payment_method}</p>
                  <p className="text-emerald-700 font-bold">Total: {money(selectedOrder.total_amount)}</p>
                </div>
              </div>

              {/* Items Table */}
              <div>
                <h3 className="text-xs font-bold uppercase text-slate-700 mb-2">Order Items</h3>
                <div className="space-y-2">
                  {(selectedOrder.items || [
                    { title: 'Bluetooth Earbuds Pro Max', qty: 1, price: 3499, image: 'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?auto=format&fit=crop&w=400&q=80' }
                  ]).map((item, i) => (
                    <div key={i} className="flex items-center justify-between p-2.5 rounded-xl border border-slate-200 bg-white">
                      <div className="flex items-center gap-3">
                        <img src={item.image} alt={item.title} className="h-10 w-10 rounded-lg object-cover" />
                        <div>
                          <p className="text-xs font-bold text-slate-900">{item.title}</p>
                          <p className="text-[11px] text-slate-500">Qty: {item.qty || 1}</p>
                        </div>
                      </div>
                      <span className="text-xs font-bold text-slate-900">{money((item.price || 0) * (item.qty || 1))}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Actions */}
              <div className="pt-3 border-t border-slate-200 flex flex-wrap gap-2 justify-end">
                <button
                  type="button"
                  onClick={() => alert(`Tracking package #ORD-${selectedOrder.id}... Courier: TCS Express`)}
                  className="px-4 py-2 bg-emerald-600 text-white font-bold text-xs rounded-xl hover:bg-emerald-700 transition"
                >
                  Track Package
                </button>
                <button
                  type="button"
                  onClick={() => alert(`Invoice #ORD-${selectedOrder.id} downloaded.`)}
                  className="px-4 py-2 bg-slate-100 border border-slate-300 text-slate-700 font-bold text-xs rounded-xl hover:bg-slate-200 transition flex items-center gap-1.5"
                >
                  <Download size={14} />
                  <span>Download Invoice</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      ) : null}

      {/* ADD ADDRESS MODAL */}
      {showAddressModal ? (
        <div className="fixed inset-0 z-[80] flex items-center justify-center bg-slate-950/60 p-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-md shadow-2xl space-y-4">
            <div className="flex justify-between items-center pb-2 border-b">
              <h3 className="text-sm font-black text-slate-900">Add Delivery Address</h3>
              <button type="button" onClick={() => setShowAddressModal(false)}><X size={18} /></button>
            </div>

            <form onSubmit={handleAddAddress} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Tag Type</label>
                <div className="flex gap-2">
                  {['Home', 'Office'].map((t) => (
                    <button
                      key={t}
                      type="button"
                      onClick={() => setNewAddressType(t)}
                      className={`flex-1 py-1.5 rounded-lg text-xs font-bold border ${
                        newAddressType === t ? 'border-emerald-600 bg-emerald-50 text-emerald-800' : 'border-slate-200 text-slate-600'
                      }`}
                    >
                      {t}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Recipient Name</label>
                <input
                  type="text"
                  value={newAddressName}
                  onChange={(e) => setNewAddressName(e.target.value)}
                  placeholder="Full name"
                  className="w-full h-9 px-3 text-xs bg-slate-50 border rounded-lg"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Mobile Phone</label>
                <input
                  type="text"
                  value={newAddressPhone}
                  onChange={(e) => setNewAddressPhone(e.target.value)}
                  placeholder="0300-XXXXXXX"
                  className="w-full h-9 px-3 text-xs bg-slate-50 border rounded-lg"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Full Street Address</label>
                <textarea
                  value={newAddressDetails}
                  onChange={(e) => setNewAddressDetails(e.target.value)}
                  placeholder="House/Flat No, Block, City"
                  className="w-full p-2.5 text-xs bg-slate-50 border rounded-lg h-20"
                  required
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-emerald-600 text-white font-bold text-xs rounded-xl hover:bg-emerald-700 transition"
              >
                Save Address
              </button>
            </form>
          </div>
        </div>
      ) : null}

      <Footer sections={footerSections} paymentMethods={paymentMethods} storeName={storeName} logoSrc={logoSrc} />
    </div>
  );
}
