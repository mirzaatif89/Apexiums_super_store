import React from 'react';

export default function CategoryGrid({ categories }) {
  return (
    <section id="categories-section" className="mx-auto max-w-7xl px-3 py-6 sm:px-4 lg:px-6">
      {/* Header Section: Explore All */}
      <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-200/80">
        <div className="flex items-center gap-2">
          <div className="h-5 w-1.5 rounded-full bg-emerald-600"></div>
          <h2 className="text-base sm:text-xl font-black text-slate-900 tracking-tight">
            Explore All
          </h2>
        </div>
        <span className="text-xs font-bold text-emerald-700 hover:text-emerald-800 transition cursor-pointer">
          See All &rarr;
        </span>
      </div>

      {/* Round / Circular Categories Layout */}
      <div className="flex gap-4 sm:gap-6 overflow-x-auto pb-3 pt-1 [-ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden sm:grid sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-13 justify-items-center">
        {categories.map((category) => {
          return (
            <button
              key={category.label}
              type="button"
              onClick={() => {
                const el = document.getElementById('products-section');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
              }}
              className="group flex flex-col items-center justify-center gap-2 shrink-0 sm:shrink cursor-pointer transition-all active:scale-95"
            >
              {/* Round Shape Circle Container */}
              <div className="relative flex h-20 w-20 sm:h-24 sm:w-24 md:h-28 md:w-28 items-center justify-center rounded-full p-1 bg-white ring-2 ring-emerald-200/90 shadow-xs transition-all duration-300 group-hover:ring-emerald-600 group-hover:shadow-md group-hover:scale-105">
                <div className="h-full w-full overflow-hidden rounded-full bg-slate-100">
                  <img
                    src={category.image}
                    alt={category.label}
                    loading="lazy"
                    className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-110"
                  />
                </div>
              </div>

              {/* Category Name Label Directly Underneath */}
              <span className="w-20 sm:w-24 md:w-28 text-center text-xs font-bold text-slate-800 transition-colors group-hover:text-emerald-700 truncate">
                {category.label}
              </span>
            </button>
          );
        })}
      </div>
    </section>
  );
}

