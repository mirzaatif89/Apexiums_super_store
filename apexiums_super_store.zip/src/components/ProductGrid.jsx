import React from 'react';
import { Heart, Plus, ShoppingCart, Eye } from 'lucide-react';

function ProductCard({ product, onSelectProduct }) {
  return (
    <article
      onClick={() => onSelectProduct && onSelectProduct(product)}
      className="group relative flex cursor-pointer flex-col overflow-hidden rounded-2xl border border-slate-100 bg-white shadow-xs transition-all duration-300 hover:-translate-y-1 hover:border-emerald-300 hover:shadow-xl hover:shadow-emerald-950/10"
    >
      {/* Product Image Container */}
      <div className="relative overflow-hidden bg-slate-50">
        <img
          src={product.image}
          alt={product.title}
          loading="lazy"
          className="aspect-square w-full object-cover transition-transform duration-500 group-hover:scale-105"
        />

        {/* Badge tag (e.g. Best Selling / Discount) */}
        {product.badge ? (
          <span className="absolute left-2.5 top-2.5 rounded-lg bg-emerald-600 px-2.5 py-1 text-[10px] font-black uppercase text-white shadow-sm tracking-wider">
            {product.badge}
          </span>
        ) : null}

        {/* Quick actions hover overlay */}
        <div className="absolute right-2.5 top-2.5 flex flex-col gap-1.5 opacity-0 transition-opacity duration-200 group-hover:opacity-100">
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
            }}
            aria-label="Wishlist"
            className="inline-flex h-8 w-8 items-center justify-center rounded-full bg-white/90 text-slate-700 shadow-md backdrop-blur-xs transition hover:bg-emerald-50 hover:text-emerald-700 active:scale-95"
          >
            <Heart size={15} />
          </button>
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              if (onSelectProduct) onSelectProduct(product);
            }}
            aria-label="Quick View"
            className="inline-flex h-8 w-8 items-center justify-center rounded-full bg-white/90 text-slate-700 shadow-md backdrop-blur-xs transition hover:bg-emerald-50 hover:text-emerald-700 active:scale-95"
          >
            <Eye size={15} />
          </button>
        </div>
      </div>

      {/* Details Container */}
      <div className="flex flex-1 flex-col justify-between p-3.5 gap-2">
        <div>
          <div className="mb-1 text-[11px] text-slate-500">
            <span className="font-semibold text-emerald-700 uppercase tracking-wider text-[10px]">{product.category}</span>
          </div>

          <h3 className="line-clamp-2 min-h-9 text-xs sm:text-sm font-semibold leading-snug text-slate-800 transition group-hover:text-emerald-700">
            {product.title}
          </h3>
        </div>

        <div className="mt-1 pt-2.5 border-t border-slate-100">
          <div className="flex items-baseline justify-between gap-1.5 flex-wrap">
            <span className="text-base sm:text-lg font-black text-emerald-700">
              Rs {product.price.toLocaleString('en-PK')}
            </span>
            {product.originalPrice ? (
              <span className="text-slate-400 line-through text-[11px] font-medium">
                Rs {product.originalPrice.toLocaleString('en-PK')}
              </span>
            ) : null}
          </div>
        </div>
      </div>
    </article>
  );
}

export default function ProductGrid({ sections, onSelectProduct }) {
  return (
    <div className="space-y-2 sm:space-y-3">
      {sections.map((section) => (
        <section key={section.title} className="mx-auto max-w-7xl px-3 sm:px-4 lg:px-6">
          <div className="rounded-2xl border border-emerald-100 bg-white p-3 sm:p-4 shadow-2xs">
            {/* Section Header */}
            <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
              <div>
                <h2 className="text-base font-extrabold uppercase tracking-wide text-slate-900">
                  {section.title}
                </h2>
                <p className="text-xs text-slate-500">{section.description}</p>
              </div>
              <a href="#" className="text-xs font-bold text-emerald-700 transition hover:underline">
                View All
              </a>
            </div>

            {/* Product Cards Grid */}
            <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
              {section.products.map((product) => (
                <ProductCard key={product.id} product={product} onSelectProduct={onSelectProduct} />
              ))}
            </div>
          </div>
        </section>
      ))}
    </div>
  );
}

