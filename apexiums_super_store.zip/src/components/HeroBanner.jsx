import React from 'react';
import { ArrowRight } from 'lucide-react';

export default function HeroBanner({ slides = [], promoBanners = [] }) {
  const [currentSlide, setCurrentSlide] = React.useState(0);

  const displaySlides = [
    {
      id: 1,
      badge: 'Limited time!',
      subtitle: 'Get Special Offer',
      offer: 'Up to 40%',
      terms: 'All Services Available | T&C Applied',
      cta: 'Claim',
      image: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=600&q=80'
    },
    {
      id: 2,
      badge: 'New Season',
      subtitle: 'Exclusive Gadgets Deal',
      offer: 'Up to 50%',
      terms: 'Free Shipping Nationwide | T&C Applied',
      cta: 'Claim',
      image: 'https://images.unsplash.com/photo-1529139574466-a303027c1d8b?auto=format&fit=crop&w=600&q=80'
    },
    {
      id: 3,
      badge: 'Hot Offer',
      subtitle: 'Top Accessories Upgrade',
      offer: 'Up to 35%',
      terms: 'Cash on Delivery Available | T&C Applied',
      cta: 'Claim',
      image: 'https://images.unsplash.com/photo-1483985988355-763728e1935b?auto=format&fit=crop&w=600&q=80'
    }
  ];

  // Auto-slide carousel
  React.useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % displaySlides.length);
    }, 4500);
    return () => clearInterval(timer);
  }, [displaySlides.length]);

  const activeSlide = displaySlides[currentSlide] || displaySlides[0];

  return (
    <section className="mx-auto max-w-7xl px-4 sm:px-6 py-3">
      {/* Section Header: #SpecialForYou */}
      <div className="flex items-center justify-between pb-2 mb-2">
        <h2 className="text-base sm:text-lg font-black text-slate-900 tracking-tight">
          #SpecialForYou
        </h2>
        <button
          type="button"
          onClick={() => {
            const el = document.getElementById('products-section');
            if (el) el.scrollIntoView({ behavior: 'smooth' });
          }}
          className="text-xs sm:text-sm font-extrabold text-[#E8262A] hover:text-red-700 tracking-wide transition cursor-pointer flex items-center gap-0.5"
        >
          See All
        </button>
      </div>

      {/* Main Banner Card (Rich Dark Banner with Vibrant Ambient Lighting & Visual Elements) */}
      <div className="relative overflow-hidden rounded-2xl sm:rounded-3xl bg-slate-950 p-4 sm:p-6 shadow-xl border border-slate-800/80">
        {/* Background Visual Glows */}
        <div className="absolute -top-12 -left-12 h-40 w-40 rounded-full bg-[#E8262A]/25 blur-3xl pointer-events-none" />
        <div className="absolute -bottom-12 -right-12 h-48 w-48 rounded-full bg-red-600/20 blur-3xl pointer-events-none" />

        <div className="relative z-10 flex items-center justify-between gap-3 sm:gap-6">
          {/* Left Text Content */}
          <div className="flex-1 min-w-0 py-1">
            {activeSlide.badge && (
              <span className="inline-flex items-center gap-1.5 rounded-full bg-gradient-to-r from-red-500/20 to-white/10 px-3 py-1 text-[10px] sm:text-xs font-extrabold uppercase tracking-wider text-white backdrop-blur-md border border-white/20 mb-2">
                <span className="h-1.5 w-1.5 rounded-full bg-[#E8262A] animate-pulse" />
                {activeSlide.badge}
              </span>
            )}
            
            <p className="text-xs sm:text-sm font-semibold text-slate-300 tracking-tight">
              {activeSlide.subtitle}
            </p>

            <h3 className="text-2xl sm:text-4xl md:text-5xl font-black tracking-tight my-1 sm:my-1.5 leading-none text-transparent bg-clip-text bg-gradient-to-r from-white via-slate-100 to-slate-300">
              {activeSlide.offer}
            </h3>

            <p className="text-[10px] sm:text-xs font-medium text-slate-400 leading-tight mb-3 sm:mb-4">
              {activeSlide.terms}
            </p>

            <button
              type="button"
              onClick={() => {
                const el = document.getElementById('products-section');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
              }}
              className="inline-flex items-center gap-2 rounded-full bg-[#E8262A] hover:bg-red-700 text-white font-extrabold text-xs sm:text-sm px-5 py-2.5 shadow-lg shadow-red-900/30 transition-all hover:scale-105 active:scale-95 cursor-pointer"
            >
              <span>{activeSlide.cta}</span>
              <ArrowRight size={15} />
            </button>
          </div>

          {/* Right Product Image - Visual Spotlight Container */}
          <div className="relative shrink-0 w-32 xs:w-40 sm:w-56 md:w-64 h-32 xs:h-40 sm:h-48 md:h-52 overflow-hidden rounded-2xl border border-white/15 shadow-2xl group">
            <img
              src={activeSlide.image}
              alt={activeSlide.subtitle}
              loading="lazy"
              className="h-full w-full object-cover object-center transition-all duration-700 group-hover:scale-108"
            />
            {/* Soft Gradient Overlay for depth */}
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950/60 via-transparent to-transparent pointer-events-none" />

            {/* Visual Floating Discount Tag Badge */}
            <div className="absolute bottom-2 left-2 right-2 bg-slate-900/80 backdrop-blur-md border border-white/10 rounded-xl px-2.5 py-1 flex items-center justify-between text-[10px] sm:text-xs text-white font-bold">
              <span className="text-red-400">🔥 Hot Deal</span>
              <span className="bg-[#E8262A] px-1.5 py-0.5 rounded-md text-[9px] font-black uppercase">Active</span>
            </div>
          </div>
        </div>
      </div>

      {/* 3-Dot Pagination Indicator Below Carousel */}
      <div className="flex items-center justify-center gap-2 mt-3">
        {displaySlides.map((_, idx) => (
          <button
            key={idx}
            type="button"
            onClick={() => setCurrentSlide(idx)}
            className={`h-2 rounded-full transition-all duration-300 cursor-pointer ${
              idx === currentSlide
                ? 'w-6 bg-[#E8262A]'
                : 'w-2 bg-slate-300 hover:bg-slate-400'
            }`}
            aria-label={`Go to slide ${idx + 1}`}
          />
        ))}
      </div>
    </section>
  );
}




