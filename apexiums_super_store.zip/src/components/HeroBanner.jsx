import React from 'react';
import { ArrowRight, ChevronLeft, ChevronRight, Headphones, ShieldCheck, Truck } from 'lucide-react';

export default function HeroBanner({ slides = [], promoBanners = [] }) {
  const [currentSlide, setCurrentSlide] = React.useState(0);

  const displaySlides = slides.length > 0 ? slides : [
    {
      id: 1,
      title: 'Big Summer Electronics Sale',
      accent: 'From Rs 9,999',
      description: 'Up to 40% off on phones, tablets and smart accessories with fast nationwide delivery.',
      cta: 'Shop Electronics',
      image: 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=1400&q=80'
    },
    {
      id: 2,
      title: 'Fashion That Feels Premium',
      accent: 'New Season Drop',
      description: 'Fresh arrivals for men, women and kids with 7-day easy returns & cash on delivery.',
      cta: 'Explore Fashion',
      image: 'https://images.unsplash.com/photo-1529139574466-a303027c1d8b?auto=format&fit=crop&w=1400&q=80'
    },
    {
      id: 3,
      title: 'Home Deals You Cannot Miss',
      accent: 'Extra Savings',
      description: 'Modern home essentials and lifestyle products with budget-friendly prices.',
      cta: 'See Home Deals',
      image: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=1400&q=80'
    }
  ];

  const nextPromo = promoBanners[0] || {
    subtitle: 'Hot Offer',
    title: 'Top Gadgets & Tech',
    image: 'https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?auto=format&fit=crop&w=600&q=80'
  };

  const secondPromo = promoBanners[1] || {
    subtitle: 'Limited Time',
    title: 'Trendy Fashion Deals',
    image: 'https://images.unsplash.com/photo-1483985988355-763728e1935b?auto=format&fit=crop&w=600&q=80'
  };

  // Auto-slide carousel
  React.useEffect(() => {
    if (displaySlides.length <= 1) return;
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % displaySlides.length);
    }, 4500);
    return () => clearInterval(timer);
  }, [displaySlides.length]);

  const activeSlide = displaySlides[currentSlide] || displaySlides[0];

  return (
    <section className="mx-auto max-w-7xl px-3 pt-1 pb-1 sm:px-4 sm:pt-2 sm:pb-1 lg:px-6">
      {/* Unified Main Card Wrapper with Banner and Attached Features Bar */}
      <div className="overflow-hidden rounded-2xl sm:rounded-3xl border border-slate-200/90 bg-white shadow-md transition-all">
        {/* TOP SECTION: Larger Main Banner (with side promos on large screens) */}
        <div className="p-1.5 sm:p-2 bg-slate-100/60">
          <div className="grid grid-cols-1 gap-2 lg:grid-cols-[1fr_300px]">
            {/* Larger Main Banner Carousel */}
            <div className="relative overflow-hidden rounded-xl sm:rounded-2xl bg-emerald-950 group">
              {/* Larger Height: min-h-[22rem] sm:min-h-[28rem] lg:min-h-[30rem] */}
              <div className="relative h-[280px] xs:h-[320px] sm:h-[400px] lg:h-[440px] w-full">
                {displaySlides.map((slide, idx) => (
                  <div
                    key={slide.id || idx}
                    className={`absolute inset-0 transition-opacity duration-700 ease-in-out ${
                      idx === currentSlide ? 'opacity-100 z-10' : 'opacity-0 z-0'
                    }`}
                  >
                    <img
                      src={slide.image}
                      alt={slide.title}
                      loading="lazy"
                      className="h-full w-full object-cover object-center"
                    />
                    <div className="absolute inset-0 bg-gradient-to-r from-emerald-950/90 via-emerald-950/50 to-transparent" />
                    
                    <div className="relative z-10 flex h-full flex-col justify-end p-5 sm:p-8 md:p-10 text-white max-w-xl">
                      {slide.accent && (
                        <span className="inline-block w-fit rounded-full bg-emerald-500/30 px-3 py-1 text-[11px] sm:text-xs font-bold uppercase tracking-wider text-emerald-200 backdrop-blur-md border border-emerald-400/30">
                          {slide.accent}
                        </span>
                      )}
                      <h1 className="mt-2 max-w-lg text-2xl xs:text-3xl sm:text-4xl lg:text-5xl font-black leading-tight text-white drop-shadow-md">
                        {slide.title}
                      </h1>
                      {slide.description && (
                        <p className="mt-2.5 max-w-md text-xs sm:text-sm text-emerald-100/95 leading-relaxed font-medium">
                          {slide.description}
                        </p>
                      )}
                      {slide.cta && (
                        <div className="mt-4 sm:mt-6">
                          <button
                            type="button"
                            onClick={() => {
                              const el = document.getElementById('products-section');
                              if (el) el.scrollIntoView({ behavior: 'smooth' });
                            }}
                            className="inline-flex items-center gap-2 rounded-xl bg-emerald-500 px-5 py-2.5 sm:px-6 sm:py-3 text-xs sm:text-sm font-black uppercase tracking-wider text-slate-950 shadow-lg shadow-emerald-950/40 transition hover:bg-emerald-400 active:scale-95 cursor-pointer"
                          >
                            <span>{slide.cta}</span>
                            <ArrowRight size={16} />
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                ))}

                {/* Left/Right Carousel Controls */}
                {displaySlides.length > 1 && (
                  <>
                    <button
                      type="button"
                      onClick={() => setCurrentSlide((prev) => (prev - 1 + displaySlides.length) % displaySlides.length)}
                      className="absolute left-2.5 top-1/2 -translate-y-1/2 z-20 flex h-8 w-8 sm:h-10 sm:w-10 items-center justify-center rounded-full bg-black/30 text-white backdrop-blur-xs transition hover:bg-black/60 opacity-80 group-hover:opacity-100 cursor-pointer"
                      aria-label="Previous Slide"
                    >
                      <ChevronLeft size={20} />
                    </button>
                    <button
                      type="button"
                      onClick={() => setCurrentSlide((prev) => (prev + 1) % displaySlides.length)}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 z-20 flex h-8 w-8 sm:h-10 sm:w-10 items-center justify-center rounded-full bg-black/30 text-white backdrop-blur-xs transition hover:bg-black/60 opacity-80 group-hover:opacity-100 cursor-pointer"
                      aria-label="Next Slide"
                    >
                      <ChevronRight size={20} />
                    </button>

                    {/* Indicators dots */}
                    <div className="absolute bottom-3 right-4 z-20 flex items-center gap-1.5">
                      {displaySlides.map((_, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => setCurrentSlide(idx)}
                          className={`h-2 rounded-full transition-all cursor-pointer ${
                            idx === currentSlide ? 'w-6 bg-emerald-400' : 'w-2 bg-white/50 hover:bg-white/80'
                          }`}
                          aria-label={`Go to slide ${idx + 1}`}
                        />
                      ))}
                    </div>
                  </>
                )}
              </div>
            </div>

            {/* Side Promo Banners (on Large Screens) */}
            <div className="hidden grid-rows-2 gap-2 lg:grid">
              {[nextPromo, secondPromo].map((promo, idx) => (
                <article key={promo.title + idx} className="relative overflow-hidden rounded-xl sm:rounded-2xl bg-slate-900 shadow-xs group">
                  <img
                    src={promo.image}
                    alt={promo.title}
                    loading="lazy"
                    className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/85 via-slate-950/30 to-transparent" />
                  <div className="absolute inset-x-0 bottom-0 p-4 text-white">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-300">
                      {promo.subtitle}
                    </span>
                    <h3 className="mt-0.5 text-sm font-bold leading-tight text-white">{promo.title}</h3>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </div>

        {/* ATTACHED FEATURES BAR directly underneath the main banner */}
        <div className="border-t border-slate-200/80 bg-white p-2.5 sm:p-4 rounded-b-2xl sm:rounded-b-3xl">
          <div className="grid grid-cols-3 gap-2 sm:gap-4">
            {[
              { label: 'Secure Payment', desc: '100% Encrypted & Safe', icon: ShieldCheck },
              { label: 'Fast Delivery', desc: '2 to 4 Days Nationwide', icon: Truck },
              { label: 'Customer Support', desc: '24/7 Dedicated Assistance', icon: Headphones }
            ].map((item) => {
              const Icon = item.icon;
              return (
                <div
                  key={item.label}
                  className="flex flex-col sm:flex-row items-center text-center sm:text-left gap-1.5 sm:gap-3 rounded-xl sm:rounded-2xl bg-slate-50/80 border border-slate-100 p-2 sm:p-3 transition hover:bg-emerald-50/50 hover:border-emerald-200/80"
                >
                  <div className="flex h-8 w-8 sm:h-11 sm:w-11 shrink-0 items-center justify-center rounded-lg sm:rounded-xl bg-emerald-100/80 text-emerald-700 ring-1 ring-emerald-200/60 shadow-2xs">
                    <Icon className="h-4 w-4 sm:h-5 sm:w-5 text-emerald-700" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[11px] sm:text-sm font-extrabold text-slate-900 tracking-tight">{item.label}</p>
                    <p className="truncate text-[9.5px] sm:text-[11px] text-slate-500 font-medium leading-tight">{item.desc}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}



