import React from 'react';
import { ArrowRight, Headphones, ShieldCheck, Truck } from 'lucide-react';

export default function HeroBanner({ slides = [], promoBanners = [] }) {
  const activeSlide = slides[0] || {
    title: 'Discover Amazing Deals Today',
    accent: 'Special Offer',
    description: 'Shop top quality products with express delivery and best price guarantee.',
    cta: 'Shop Now',
    image: 'https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?auto=format&fit=crop&w=1200&q=80'
  };

  const nextPromo = promoBanners[0] || {
    subtitle: 'Hot Offer',
    title: 'Top Gadgets & Tech',
    image: 'https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?auto=format&fit=crop&w=600&q=80'
  };

  const secondPromo = promoBanners[1] || {
    subtitle: 'Limited Time',
    title: 'Trendy Fashion Deals',
    image: 'https://images.unsplash.com/photo-1483985988355-763728e1935b?auto=format&fit=crop&w=600&q=80'
  };

  return (
    <section className="mx-auto max-w-7xl px-3 pt-3 pb-2 sm:px-4 lg:px-6">
      <div className="grid grid-cols-1 gap-3 lg:grid-cols-[1fr_320px]">
        {/* Main Single Banner */}
        <div className="relative overflow-hidden rounded-2xl bg-emerald-950 shadow-md">
          <div className="relative min-h-[16rem] sm:min-h-[22rem] lg:min-h-[24rem]">
            <img
              src={activeSlide.image}
              alt={activeSlide.title}
              loading="lazy"
              className="absolute inset-0 h-full w-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-emerald-950/90 via-emerald-950/40 to-transparent" />
            
            <div className="relative z-10 flex h-full min-h-[16rem] sm:min-h-[22rem] lg:min-h-[24rem] flex-col justify-end p-5 sm:p-8 text-white">
              {activeSlide.accent && (
                <span className="inline-block w-fit rounded-full bg-emerald-500/30 px-3 py-1 text-xs font-bold uppercase tracking-wider text-emerald-200 backdrop-blur-md border border-emerald-400/30">
                  {activeSlide.accent}
                </span>
              )}
              <h1 className="mt-2.5 max-w-xl text-2xl font-black leading-tight sm:text-4xl text-white drop-shadow-sm">
                {activeSlide.title}
              </h1>
              {activeSlide.description && (
                <p className="mt-2 max-w-md text-xs sm:text-sm text-emerald-100/90 leading-relaxed">
                  {activeSlide.description}
                </p>
              )}
              {activeSlide.cta && (
                <div className="mt-4">
                  <button
                    type="button"
                    className="inline-flex items-center gap-2 rounded-xl bg-emerald-500 px-5 py-2.5 text-xs font-bold uppercase tracking-wider text-slate-950 shadow-lg shadow-emerald-950/30 transition hover:bg-emerald-400 active:scale-95 cursor-pointer"
                  >
                    <span>{activeSlide.cta}</span>
                    <ArrowRight size={15} />
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Side Promo Banners */}
        <div className="hidden grid-rows-2 gap-3 lg:grid">
          {[nextPromo, secondPromo].map((promo, idx) => (
            <article key={promo.title + idx} className="relative overflow-hidden rounded-2xl bg-slate-900 shadow-sm group">
              <img
                src={promo.image}
                alt={promo.title}
                loading="lazy"
                className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/85 via-slate-950/30 to-transparent" />
              <div className="absolute inset-x-0 bottom-0 p-4 text-white">
                <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-300">
                  {promo.subtitle}
                </span>
                <h3 className="mt-0.5 text-base font-bold leading-tight text-white">{promo.title}</h3>
              </div>
            </article>
          ))}
        </div>
      </div>

      {/* Service Highlights - 3 Equal Feature Cards in a Single Line on All Screens */}
      <div className="mt-3.5 sm:mt-4 grid grid-cols-3 gap-1.5 sm:gap-3.5">
        {[
          { label: 'Secure Payment', desc: '100% Encrypted & Safe', icon: ShieldCheck },
          { label: 'Fast Delivery', desc: 'Express Shipping', icon: Truck },
          { label: 'Customer Support', desc: '24/7 Dedicated Help', icon: Headphones }
        ].map((item) => {
          const Icon = item.icon;
          return (
            <div
              key={item.label}
              className="flex flex-col sm:flex-row items-center text-center sm:text-left gap-1.5 sm:gap-3.5 rounded-xl sm:rounded-2xl border border-slate-200/80 bg-white p-2 sm:p-4 shadow-2xs transition hover:border-emerald-300 hover:shadow-md"
            >
              <div className="flex h-8 w-8 sm:h-12 sm:w-12 shrink-0 items-center justify-center rounded-lg sm:rounded-xl bg-emerald-50/90 text-emerald-700 ring-1 ring-emerald-200/60 shadow-2xs">
                <Icon className="h-4 w-4 sm:h-6 sm:w-6 text-emerald-600" />
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate text-[11px] sm:text-sm font-extrabold text-slate-900 tracking-tight">{item.label}</p>
                <p className="truncate text-[9.5px] sm:text-[11px] text-slate-500 font-medium leading-tight">{item.desc}</p>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}


