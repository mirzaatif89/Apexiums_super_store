import React from 'react';
import { Flame, Gift, Sparkles, Tag, Truck } from 'lucide-react';

export default function CategoryNav({ navItems = [] }) {
  const [selectedCategory, setSelectedCategory] = React.useState(navItems[0]?.label || 'Electronics');

  const quickDeals = [
    { label: 'Flash Sale', icon: Flame, badge: 'Hot', color: 'text-amber-700 bg-amber-50 border-amber-200' },
    { label: 'Free Shipping', icon: Truck, badge: 'Rs 0', color: 'text-slate-700 bg-slate-50 border-slate-200 hover:border-emerald-200 hover:text-emerald-700' },
    { label: 'Vouchers', icon: Tag, badge: 'Save', color: 'text-slate-700 bg-slate-50 border-slate-200 hover:border-emerald-200 hover:text-emerald-700' },
    { label: 'Official Stores', icon: Sparkles, badge: '100%', color: 'text-slate-700 bg-slate-50 border-slate-200 hover:border-emerald-200 hover:text-emerald-700' },
    { label: 'Everyday Low Prices', icon: Gift, badge: 'Deals', color: 'text-slate-700 bg-slate-50 border-slate-200 hover:border-emerald-200 hover:text-emerald-700' }
  ];

  return (
    <section className="border-b border-slate-100 bg-white shadow-xs">
      <div className="mx-auto max-w-7xl px-3 sm:px-4 lg:px-6">
        <div className="flex items-center justify-between gap-3 py-2 overflow-x-auto [-ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden scroll-smooth">
          {/* Main Category Dropdowns */}
          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            {navItems.map((item) => {
              const isActive = selectedCategory === item.label;
              return (
                <div key={item.label} className="group relative shrink-0">
                  <button
                    type="button"
                    onClick={() => setSelectedCategory(item.label)}
                    className={`inline-flex min-h-9 items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs whitespace-nowrap transition-all cursor-pointer ${
                      isActive
                        ? 'bg-emerald-50 text-emerald-700 font-bold ring-1 ring-emerald-200/60 shadow-2xs'
                        : 'font-medium text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                    }`}
                  >
                    <span>{item.label}</span>
                    {isActive ? (
                      <span className="h-1.5 w-1.5 rounded-full bg-emerald-600 inline-block shrink-0" />
                    ) : null}
                  </button>

                  {/* Submenu Dropdown */}
                  <div className="invisible absolute left-0 top-full z-30 mt-1 w-[20rem] translate-y-1 rounded-2xl border border-slate-100 bg-white p-4 opacity-0 shadow-xl shadow-slate-900/10 transition-all duration-200 group-hover:visible group-hover:translate-y-0 group-hover:opacity-100">
                    <p className="mb-2 text-[11px] font-bold uppercase tracking-wider text-emerald-700">
                      {item.label} Subcategories
                    </p>
                    <div className="grid grid-cols-2 gap-1.5">
                      {item.items.map((subItem) => (
                        <a
                          key={subItem}
                          href="#"
                          className="rounded-lg bg-slate-50 px-3 py-2 text-xs font-medium text-slate-700 transition hover:bg-emerald-50 hover:text-emerald-700 hover:font-semibold"
                        >
                          {subItem}
                        </a>
                      ))}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Quick Deal Badges */}
          <div className="hidden items-center gap-2 lg:flex shrink-0">
            {quickDeals.map((deal) => {
              const Icon = deal.icon;
              return (
                <a
                  key={deal.label}
                  href="#"
                  className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-xs font-semibold whitespace-nowrap transition-all hover:opacity-90 active:scale-95 ${deal.color}`}
                >
                  <Icon size={14} className="shrink-0" />
                  <span>{deal.label}</span>
                  <span className="rounded-full bg-white px-1.5 py-0.5 text-[10px] font-extrabold shadow-2xs">
                    {deal.badge}
                  </span>
                </a>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}

