import React from 'react';
import { AdminProvider, useAdmin } from '../context/AdminContext';
import Sidebar from './layout/Sidebar';
import Header from './layout/Header';
import ToastContainer from './layout/ToastContainer';
import GlobalSearchModal from './layout/GlobalSearchModal';

// Views
import DashboardView from './dashboard/DashboardView';
import ProductListing from './catalog/ProductListing';
import CategoriesView from './catalog/CategoriesView';
import StockManagement from './catalog/StockManagement';
import OrdersView from './sales/OrdersView';
import ReturnsView from './sales/ReturnsView';
import CustomersView from './sales/CustomersView';
import BannersView from './marketing/BannersView';
import AdsView from './marketing/AdsView';
import InvestorsView from './marketplace/InvestorsView';
import StaffView from './marketplace/StaffView';
import SellersView from './marketplace/SellersView';
import PermissionsView from './marketplace/PermissionsView';
import RevenueView from './finance/RevenueView';
import ExpensesView from './finance/ExpensesView';
import SoftwareFeesView from './finance/SoftwareFeesView';
import StaffSalariesView from './finance/StaffSalariesView';
import DeliveryExpensesView from './finance/DeliveryExpensesView';
import NotificationsView from './common/NotificationsView';
import SettingsView from './common/SettingsView';

const AdminDashboardContent = ({ session, storeName, logoSrc, onLogout }) => {
  const { activeTab } = useAdmin();

  const renderActiveView = () => {
    switch (activeTab) {
      case 'Dashboard':
        return <DashboardView />;
      case 'Product Listing':
        return <ProductListing />;
      case 'Categories':
        return <CategoriesView />;
      case 'Stock':
        return <StockManagement />;
      case 'Orders':
        return <OrdersView />;
      case 'Returns':
        return <ReturnsView />;
      case 'Customers':
        return <CustomersView />;
      case 'Banners':
        return <BannersView />;
      case 'Ads':
        return <AdsView />;
      case 'Investors':
        return <InvestorsView />;
      case 'Staff':
        return <StaffView />;
      case 'Sellers':
      case 'Whole Sellers':
      case 'Businesses':
        return <SellersView />;
      case 'Permissions':
        return <PermissionsView />;
      case 'Revenue':
        return <RevenueView />;
      case 'Expense':
        return <ExpensesView />;
      case 'Software Fees':
        return <SoftwareFeesView />;
      case 'Staff Salaries':
        return <StaffSalariesView />;
      case 'Delivery Expenses':
        return <DeliveryExpensesView />;
      case 'Notifications':
        return <NotificationsView />;
      case 'Settings':
        return <SettingsView />;
      default:
        return <DashboardView />;
    }
  };

  return (
    <div className="flex h-screen bg-slate-100 font-sans text-slate-900 overflow-hidden antialiased">
      {/* Sidebar navigation */}
      <Sidebar storeName={storeName} logoSrc={logoSrc} onLogout={onLogout} session={session} />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top Header */}
        <Header session={session} onLogout={onLogout} />

        {/* Scrollable View Canvas */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 space-y-6">
          {renderActiveView()}
        </main>
      </div>

      {/* Global Utilities */}
      <ToastContainer />
      <GlobalSearchModal />
    </div>
  );
};

export default function AdminDashboard(props) {
  return (
    <AdminProvider>
      <AdminDashboardContent {...props} />
    </AdminProvider>
  );
}
