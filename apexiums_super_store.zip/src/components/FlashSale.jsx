import React from 'react';
import { ChevronRight, Clock, Flame } from 'lucide-react';

const pad = (value) => String(value).padStart(2, '0');

export default function FlashSale({ products, onProductClick }) {
  const [remaining, setRemaining] = React.useState({ h: 4, m: 59, s: 59 });

  React.useEffect(() => {
    const timer = window.setInterval(() => {
      setRemaining((current) => {
        let total = current.h * 3600 + current.m * 60 + current.s - 1;
        if (total < 0) total = 4 * 3600 + 59 * 60 + 59;
        return {
          h: Math.floor(total / 3600),
          m: Math.floor((total % 3600) / 60),
          s: total % 60
        };
      });
    }, 1000);

    return () => window.clearInterval(timer);
  }, []);

  return (
    <section className="mx-auto max-w-7xl px-3 pt-1 pb-1 sm:px-4 sm:pt-1.5 sm:pb-1.5 lg:px-6">
      <div className="rounded-2xl sm:rounded-3xl border border-emerald-100 bg-white p-3.5 sm:p-5 shadow-xs">
        {/* Flash Sale Header Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-1.5 text-emerald-700 font-black text-lg sm:text-xl uppercase tracking-wide">
              <Flame className="text-amber-500 fill-amber-500 animate-pulse" size={22} />
              <span>FLASH SALE</span>
            </div>

            <div className="flex items-center gap-1 text-xs font-semibold text-slate-500">
              <span className="hidden sm:inline">Ending in</span>
              <div className="flex items-center gap-1">
                <span className="inline-flex h-6 min-w-6 items-center justify-center rounded bg-slate-900 px-1.5 text-xs font-extrabold text-white">
                  {pad(remaining.h)}
                </span>
                <span className="font-bold text-slate-900">:</span>
                <span className="inline-flex h-6 min-w-6 items-center justify-center rounded bg-slate-900 px-1.5 text-xs font-extrabold text-white">
                  {pad(remaining.m)}
                </span>
                <span className="font-bold text-slate-900">:</span>
                <span className="inline-flex h-6 min-w-6 items-center justify-center rounded bg-slate-900 px-1.5 text-xs font-extrabold text-white">
                  {pad(remaining.s)}
                </span>
              </div>
            </div>
          </div>

          <a
            href="#categories-section"
            className="inline-flex items-center gap-1 rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-1.5 text-xs font-bold text-emerald-700 transition hover:bg-emerald-100"
          >
            <span>EXPLORE DEALS</span>
            <ChevronRight size={14} />
          </a>
        </div>
      </div>
    </section>
  );
}

