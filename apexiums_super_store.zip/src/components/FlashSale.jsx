import React from 'react';
import { ChevronRight, Flame, Heart, ShoppingBag, Star, Zap } from 'lucide-react';

const pad = (value) => String(value).padStart(2, '0');

export default function FlashSale({ products = [], onProductClick, onAddToCart }) {
  const [activeTab, setActiveTab] = React.useState('All');
  const [remaining, setRemaining] = React.useState({ h: 2, m: 12, s: 56 });
  const [wishlistedIds, setWishlistedIds] = React.useState(new Set());

  const tabs = ['All', 'Newest', 'Popular', 'Clothes'];

  const toggleWishlist = (id, e) => {
    e.stopPropagation();
    setWishlistedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  React.useEffect(() => {
    const timer = window.setInterval(() => {
      setRemaining((current) => {
        let total = current.h * 3600 + current.m * 60 + current.s - 1;
        if (total < 0) total = 2 * 3600 + 12 * 60 + 56;
        return {
          h: Math.floor(total / 3600),
          m: Math.floor((total % 3600) / 60),
          s: total % 60
        };
      });
    }, 1000);

    return () => window.clearInterval(timer);
  }, []);

  const displayedProducts = React.useMemo(() => {
    if (!products || products.length === 0) return [];
    let list = [...products];
    if (activeTab === 'Popular') {
      list.sort((a, b) => (b.reviewsCount || 50) - (a.reviewsCount || 50));
    } else if (activeTab === 'Newest') {
      list.reverse();
    } else if (activeTab === 'Clothes') {
      list = list.filter((p) => p.category?.toLowerCase().includes('fash') || p.category?.toLowerCase().includes('cloth'));
      if (list.length === 0) list = products.slice(0, 4);
    }
    return list;
  }, [products, activeTab]);

  return (
    <section className="mx-auto max-w-7xl px-3 sm:px-4 lg:px-6 pt-1 pb-2">
      <div className="rounded-2xl sm:rounded-3xl border border-slate-200/80 bg-white p-3.5 sm:p-5 shadow-2xs">
        {/* Top Header Bar: Flash Sale Title & Closing Timer */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 border-b border-slate-100 pb-3">
          <div className="flex items-center justify-between sm:justify-start gap-3 w-full sm:w-auto">
            <div className="flex items-center gap-1.5 text-slate-900 font-black text-base sm:text-lg tracking-tight">
              <Flame className="fill-red-600 text-red-600" size={20} />
              <span>Flash Sale</span>
            </div>

            {/* Countdown timer with black box badges */}
            <div className="flex items-center gap-2 text-xs font-extrabold text-slate-800 bg-slate-50 border border-slate-200/80 px-3 py-1.5 rounded-2xl shadow-2xs">
              <span className="text-xs text-slate-500 font-bold uppercase tracking-wider hidden sm:inline">Closing in:</span>
              <div className="flex items-center gap-1 font-mono text-xs font-black">
                <span className="flex h-7 w-7 sm:h-8 sm:w-8 items-center justify-center rounded-lg bg-slate-900 text-white shadow-xs">
                  {pad(remaining.h)}
                </span>
                <span className="text-slate-900 font-black text-sm">:</span>
                <span className="flex h-7 w-7 sm:h-8 sm:w-8 items-center justify-center rounded-lg bg-slate-900 text-white shadow-xs">
                  {pad(remaining.m)}
                </span>
                <span className="text-slate-900 font-black text-sm">:</span>
                <span className="flex h-7 w-7 sm:h-8 sm:w-8 items-center justify-center rounded-lg bg-slate-900 text-white shadow-xs">
                  {pad(remaining.s)}
                </span>
              </div>
            </div>
          </div>

          {/* Filter Tabs removed as requested */}
        </div>

        {/* Product Cards Grid */}
        <div className="mt-4 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 sm:gap-4">
          {displayedProducts.map((product) => {
            const discountPercent = product.originalPrice
              ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
              : null;

            return (
              <article
                key={product.id}
                onClick={() => onProductClick && onProductClick(product)}
                className="group relative flex flex-col justify-between overflow-hidden rounded-2xl border border-slate-200/80 bg-white p-2.5 sm:p-3 shadow-2xs transition-all duration-300 hover:-translate-y-1 hover:border-red-300 hover:shadow-lg cursor-pointer"
              >
                <div>
                  {/* Image container */}
                  <div className="relative aspect-square w-full overflow-hidden rounded-xl bg-slate-50">
                    <img
                      src={product.image}
                      alt={product.title}
                      loading="lazy"
                      className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                    />

                    {/* Wishlist Icon */}
                    <button
                      type="button"
                      onClick={(e) => toggleWishlist(product.id, e)}
                      className={`absolute right-2 top-2 flex h-7 w-7 items-center justify-center rounded-full bg-white/90 text-slate-700 shadow-xs backdrop-blur-xs transition hover:bg-white hover:scale-110 active:scale-95 cursor-pointer z-10 ${
                        wishlistedIds.has(product.id) ? 'text-red-600' : 'hover:text-red-600'
                      }`}
                      title="Wishlist"
                      aria-label="Wishlist"
                    >
                      <Heart size={14} className={wishlistedIds.has(product.id) ? 'fill-red-600' : ''} />
                    </button>

                    {/* Discount Badge */}
                    {discountPercent ? (
                      <span className="absolute left-2 top-2 rounded-lg bg-red-600 px-2 py-0.5 text-[10px] font-black uppercase text-white shadow-xs tracking-wider">
                        -{discountPercent}%
                      </span>
                    ) : product.badge ? (
                      <span className="absolute left-2 top-2 rounded-lg bg-red-600 px-2 py-0.5 text-[10px] font-black uppercase text-white shadow-xs tracking-wider">
                        {product.badge}
                      </span>
                    ) : null}
                  </div>

                  {/* Info */}
                  <div className="mt-2.5">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-red-600">
                      {product.category || 'Deal'}
                    </span>
                    <h3 className="line-clamp-2 min-h-[32px] text-xs font-bold leading-snug text-slate-800 transition group-hover:text-red-600 mt-0.5">
                      {product.title}
                    </h3>

                    {/* Rating stars */}
                    <div className="mt-1 flex items-center gap-1 text-[11px] text-amber-500">
                      <Star size={12} className="fill-amber-400 text-amber-400" />
                      <span className="font-bold text-slate-700 text-[11px]">{product.rating || '4.8'}</span>
                      <span className="text-slate-400 text-[10px]">({product.reviewsCount || 42})</span>
                    </div>
                  </div>
                </div>

                {/* Price and Add to Cart */}
                <div className="mt-2.5 pt-2 border-t border-slate-100 flex items-center justify-between gap-1">
                  <div>
                    <div className="text-xs sm:text-sm font-black text-red-600">
                      Rs {product.price.toLocaleString('en-PK')}
                    </div>
                    {product.originalPrice ? (
                      <div className="text-[10px] text-slate-400 line-through font-medium">
                        Rs {product.originalPrice.toLocaleString('en-PK')}
                      </div>
                    ) : null}
                  </div>

                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      if (onAddToCart) onAddToCart(product);
                      else if (onProductClick) onProductClick(product);
                    }}
                    className="flex h-8 w-8 items-center justify-center rounded-xl bg-red-600 text-white shadow-xs transition hover:bg-red-700 active:scale-95 cursor-pointer shrink-0"
                    title="Add to Cart"
                    aria-label="Add to Cart"
                  >
                    <ShoppingBag size={15} />
                  </button>
                </div>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
}

