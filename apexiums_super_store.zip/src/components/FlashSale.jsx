import React from 'react';
import { ChevronRight, Clock, Flame } from 'lucide-react';

const pad = (value) => String(value).padStart(2, '0');

export default function FlashSale({ products, onProductClick }) {
  const [remaining, setRemaining] = React.useState({ h: 4, m: 59, s: 59 });

  React.useEffect(() => {
    const timer = window.setInterval(() => {
      setRemaining((current) => {
        let total = current.h * 3600 + current.m * 60 + current.s - 1;
        if (total < 0) total = 4 * 3600 + 59 * 60 + 59;
        return {
          h: Math.floor(total / 3600),
          m: Math.floor((total % 3600) / 60),
          s: total % 60
        };
      });
    }, 1000);

    return () => window.clearInterval(timer);
  }, []);

  return (
    <section className="mx-auto max-w-7xl px-3 py-4 sm:px-4 lg:px-6">
      <div className="rounded-2xl border border-emerald-100 bg-white p-4 shadow-sm">
        {/* Flash Sale Header Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-3">
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-1.5 text-emerald-700 font-black text-lg sm:text-xl uppercase tracking-wide">
              <Flame className="text-amber-500 fill-amber-500 animate-pulse" size={22} />
              <span>FLASH SALE</span>
            </div>

            <div className="flex items-center gap-1 text-xs font-semibold text-slate-500">
              <span className="hidden sm:inline">Ending in</span>
              <div className="flex items-center gap-1">
                <span className="inline-flex h-6 min-w-6 items-center justify-center rounded bg-slate-900 px-1.5 text-xs font-extrabold text-white">
                  {pad(remaining.h)}
                </span>
                <span className="font-bold text-slate-900">:</span>
                <span className="inline-flex h-6 min-w-6 items-center justify-center rounded bg-slate-900 px-1.5 text-xs font-extrabold text-white">
                  {pad(remaining.m)}
                </span>
                <span className="font-bold text-slate-900">:</span>
                <span className="inline-flex h-6 min-w-6 items-center justify-center rounded bg-slate-900 px-1.5 text-xs font-extrabold text-white">
                  {pad(remaining.s)}
                </span>
              </div>
            </div>
          </div>

          <a
            href="#"
            className="inline-flex items-center gap-1 rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-1.5 text-xs font-bold text-emerald-700 transition hover:bg-emerald-100"
          >
            <span>SHOP ALL DEALS</span>
            <ChevronRight size={14} />
          </a>
        </div>

        {/* Product Carousel Grid */}
        <div className="mt-3.5 flex gap-2.5 sm:gap-3.5 overflow-x-auto pb-2 [-ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
          {products.map((product) => (
            <article
              key={product.id}
              onClick={() => onProductClick && onProductClick(product)}
              className="group min-w-[8.5rem] xs:min-w-[9.5rem] sm:min-w-[12rem] md:min-w-[13rem] flex-none cursor-pointer overflow-hidden rounded-xl border border-slate-200/80 bg-white transition-all duration-300 hover:-translate-y-1 hover:border-emerald-400 hover:shadow-lg hover:shadow-emerald-900/5"
            >
              <div className="relative overflow-hidden bg-slate-50/80 p-2 h-24 sm:h-32 flex items-center justify-center">
                <img
                  src={product.image}
                  alt={product.title}
                  loading="lazy"
                  className="h-full max-h-full w-auto object-contain transition-transform duration-500 group-hover:scale-105"
                />
                <span className="absolute left-1.5 top-1.5 sm:left-2 sm:top-2 rounded-md bg-amber-500 px-1.5 py-0.5 text-[9px] sm:text-[10px] font-black uppercase text-slate-950 shadow-xs">
                  {product.badge}
                </span>
              </div>

              <div className="grid gap-1 p-2.5 sm:p-3">
                <h3 className="line-clamp-2 min-h-7 sm:min-h-9 text-[11px] sm:text-xs font-medium text-slate-800 leading-tight sm:leading-4 group-hover:text-emerald-700 transition">
                  {product.title}
                </h3>

                <div>
                  <div className="text-xs sm:text-sm font-extrabold text-emerald-700">
                    Rs {product.price.toLocaleString('en-PK')}
                  </div>
                  <div className="flex items-center gap-1 text-[10px] sm:text-[11px] text-slate-400">
                    <span className="line-through">Rs {product.originalPrice.toLocaleString('en-PK')}</span>
                  </div>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

